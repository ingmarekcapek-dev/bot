from __future__ import annotations
import time
import pandas as pd
import ccxt.async_support as ccxt
from market_data.timeframes import TF_MS

CLASSES = {"binance": "binanceusdm", "bybit": "bybit"}   # USDT-M Futures / USDT Perpetual


class Exchange:
    def __init__(self, name: str, api_key: str = "", secret: str = "", demo: bool = False):
        if name not in CLASSES:
            raise ValueError("EXCHANGE має бути binance або bybit")
        p = {"enableRateLimit": True, "options": {"defaultType": "swap", "adjustForTimeDifference": True}}
        if api_key:
            p.update(apiKey=api_key, secret=secret)
        self.ex = getattr(ccxt, CLASSES[name])(p)
        if demo:
            if hasattr(self.ex, "enable_demo_trading"): self.ex.enable_demo_trading(True)
            else: self.ex.set_sandbox_mode(True)
        self.name, self.demo, self.authed = name, demo, bool(api_key)

    async def load(self):
        await self.ex.load_markets()

    async def close(self):
        await self.ex.close()

    def market(self, symbol): return self.ex.market(symbol)
    def round_amount(self, symbol, q: float) -> float:
        try: return float(self.ex.amount_to_precision(symbol, q))
        except Exception: return 0.0      # менше мінімального кроку -> 0 (розмір буде відхилено)
    def round_price(self, symbol, px: float) -> float: return float(self.ex.price_to_precision(symbol, px))

    async def ohlcv(self, symbol: str, tf: str, limit: int) -> pd.DataFrame:
        raw = await self.ex.fetch_ohlcv(symbol, tf, limit=limit + 1)
        df = pd.DataFrame(raw, columns=["ts", "open", "high", "low", "close", "volume"])
        now = int(time.time() * 1000)
        return df[df["ts"] + TF_MS[tf] <= now].tail(limit).reset_index(drop=True)   # лише закриті

    async def snapshot(self, symbol: str) -> dict:
        """Spread, funding, mark/index, OI, 24h обсяг. Відсутнє через API -> None."""
        out = {"spread_pct": None, "funding": None, "mark": None, "index": None, "oi": None, "quote_volume": None}
        try:
            ob = await self.ex.fetch_order_book(symbol, 5)
            bid, ask = ob["bids"][0][0], ob["asks"][0][0]
            out["spread_pct"] = (ask - bid) / ((ask + bid) / 2) * 100
        except Exception: pass
        try:
            fr = await self.ex.fetch_funding_rate(symbol)
            out.update(funding=fr.get("fundingRate"), mark=fr.get("markPrice"), index=fr.get("indexPrice"))
        except Exception: pass
        try: out["oi"] = (await self.ex.fetch_open_interest(symbol)).get("openInterestAmount")
        except Exception: pass
        try: out["quote_volume"] = (await self.ex.fetch_ticker(symbol)).get("quoteVolume")
        except Exception: pass
        return out

    async def history(self, symbol: str, tf: str, days: int) -> pd.DataFrame:
        since = int((time.time() - days * 86400) * 1000); rows = []
        while True:
            chunk = await self.ex.fetch_ohlcv(symbol, tf, since=since, limit=1000)
            if not chunk: break
            rows += chunk
            nxt = chunk[-1][0] + TF_MS[tf]
            if nxt <= since or len(chunk) < 2: break
            since = nxt
        df = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close", "volume"]).drop_duplicates("ts")
        return df[df["ts"] + TF_MS[tf] <= time.time() * 1000].reset_index(drop=True)
