from __future__ import annotations
from pydantic_settings import BaseSettings, SettingsConfigDict


def _dec(value: str, key: str) -> str:
    if not key or not value:
        return value
    from cryptography.fernet import Fernet
    try:
        return Fernet(key.encode()).decrypt(value.encode()).decode()
    except Exception:
        return value  # значення не зашифроване


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    telegram_bot_token: str
    admin_ids: str = ""
    exchange: str = "binance"
    demo_api_key: str = ""
    demo_api_secret: str = ""
    live_api_key: str = ""
    live_api_secret: str = ""
    encryption_key: str = ""
    database_url: str = "sqlite+aiosqlite:///data/bot.db"
    state_file: str = "data/state.json"
    loop_interval_sec: int = 20
    tv_enable: bool = False
    tv_port: int = 8080
    tv_allowed_ips: str = ""

    @property
    def admins(self) -> set[int]:
        return {int(x) for x in self.admin_ids.replace(" ", "").split(",") if x.strip().isdigit()}

    def keys(self, mode: str) -> tuple[str, str]:
        k, s = (self.live_api_key, self.live_api_secret) if mode == "live" else (self.demo_api_key, self.demo_api_secret)
        return k, _dec(s, self.encryption_key)
