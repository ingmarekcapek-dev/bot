def signal_text(sig, size=None, leverage=None, executed=False):
    f = lambda x: f"{x:.6g}"
    fvg = f"{f(sig.fvg[0])}–{f(sig.fvg[1])}" if sig.fvg else "—"
    q = (f"\nПлече: {leverage}x\nРозмір позиції: {size['qty']}\nРизик: {size['risk_usdt']:.2f} USDT"
         if size else "\nРозмір позиції: не розраховано")
    return (f"{'🟢' if sig.direction == 'LONG' else '🔴'} <b>Торговий сигнал</b>\n"
            f"Монета: {sig.symbol}\nНапрямок: <b>{sig.direction}</b>\nЦіна входу: {f(sig.entry)}\n"
            f"Stop Loss: {f(sig.sl)}\nTP1: {f(sig.tp1)}\nTP2: {f(sig.tp2)}\nTP3: {f(sig.tp3)}{q}\n"
            f"Risk/Reward: 1:{sig.rr}\nТаймфрейм: {sig.tf}\n"
            f"Order Block: {f(sig.ob.lo)}–{f(sig.ob.hi)} ({sig.ob.kind})\nBOS/CHoCH: {sig.structure}\nFVG: {fvg}\n"
            f"Причина входу:\n• " + "\n• ".join(sig.reasons) + f"\nВпевненість: {sig.confidence}/100\n"
            + ("✅ Автоторгівля: ордер відправляється" if executed else "ℹ️ Лише сигнал (автоторгівля вимкнена або заблокована)"))


def opened_text(pos):
    return (f"✅ <b>Позицію відкрито</b> [{pos.mode.upper()}]\n{pos.symbol} {pos.side.upper()}\n"
            f"Фактичний вхід: {pos.entry:.6g}\nQty: {pos.qty}\nSL: {pos.sl:.6g}\n"
            f"TP: " + ", ".join(f"{t:.6g}" for t, _ in pos.legs))


def closed_text(pos, pnl, reason):
    return (f"{'🟩' if pnl >= 0 else '🟥'} <b>Позиція закрита</b> [{pos.mode.upper()}]\n{pos.symbol} {pos.side.upper()}\n"
            f"Причина: {reason}\nPnL: {pnl:+.2f} USDT (комісії {pos.fees:.2f})")
