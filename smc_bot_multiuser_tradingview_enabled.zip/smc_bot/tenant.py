from __future__ import annotations
import os, sqlite3, hashlib, secrets
from pathlib import Path
from cryptography.fernet import Fernet
from engine import App

class AccountStore:
    def __init__(self, key: str, path='data/accounts.sqlite3'):
        if not key:
            raise RuntimeError('ENCRYPTION_KEY обов’язковий для багатокористувацького режиму')
        self.fernet = Fernet(key.encode())
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS allowed_users (user_id INTEGER PRIMARY KEY)')
        self.db.execute('CREATE TABLE IF NOT EXISTS api_accounts (user_id INTEGER, mode TEXT, api_key BLOB, api_secret BLOB, PRIMARY KEY(user_id, mode))')
        self.db.execute('CREATE TABLE IF NOT EXISTS tv_webhooks (user_id INTEGER PRIMARY KEY, token_hash TEXT UNIQUE NOT NULL, token_encrypted BLOB NOT NULL, enabled INTEGER NOT NULL DEFAULT 1)')
        self.db.execute('CREATE TABLE IF NOT EXISTS tv_seen_events (user_id INTEGER NOT NULL, event_id TEXT NOT NULL, seen_at INTEGER NOT NULL, PRIMARY KEY(user_id,event_id))')
        self.db.commit()
    def allow(self, uid):
        self.db.execute('INSERT OR IGNORE INTO allowed_users(user_id) VALUES(?)', (int(uid),)); self.db.commit()
    def revoke(self, uid):
        self.db.execute('DELETE FROM allowed_users WHERE user_id=?', (int(uid),))
        self.db.execute('DELETE FROM api_accounts WHERE user_id=?', (int(uid),))
        self.db.execute('DELETE FROM tv_webhooks WHERE user_id=?', (int(uid),))
        self.db.execute('DELETE FROM tv_seen_events WHERE user_id=?', (int(uid),)); self.db.commit()
    def allowed(self, uid):
        return self.db.execute('SELECT 1 FROM allowed_users WHERE user_id=?', (int(uid),)).fetchone() is not None
    def save_keys(self, uid, mode, api_key, secret):
        self.db.execute('INSERT OR REPLACE INTO api_accounts VALUES(?,?,?,?)', (int(uid), mode, self.fernet.encrypt(api_key.encode()), self.fernet.encrypt(secret.encode())))
        self.db.commit()
    def keys(self, uid, mode):
        row = self.db.execute('SELECT api_key,api_secret FROM api_accounts WHERE user_id=? AND mode=?', (int(uid), mode)).fetchone()
        if not row: return ('', '')
        return self.fernet.decrypt(row[0]).decode(), self.fernet.decrypt(row[1]).decode()
    def has_keys(self, uid, mode):
        return self.db.execute('SELECT 1 FROM api_accounts WHERE user_id=? AND mode=?', (int(uid), mode)).fetchone() is not None
    def create_tv_token(self, uid):
        token = secrets.token_urlsafe(32)
        self.db.execute('INSERT OR REPLACE INTO tv_webhooks(user_id,token_hash,token_encrypted,enabled) VALUES(?,?,?,1)', (int(uid), hashlib.sha256(token.encode()).hexdigest(), self.fernet.encrypt(token.encode())))
        self.db.commit(); return token
    def tv_status(self, uid):
        row = self.db.execute('SELECT token_encrypted,enabled FROM tv_webhooks WHERE user_id=?', (int(uid),)).fetchone()
        return (self.fernet.decrypt(row[0]).decode(), bool(row[1])) if row else ('', False)
    def set_tv_enabled(self, uid, enabled):
        self.db.execute('UPDATE tv_webhooks SET enabled=? WHERE user_id=?', (int(bool(enabled)), int(uid))); self.db.commit()
    def tv_owner(self, token):
        digest = hashlib.sha256(token.encode()).hexdigest()
        row = self.db.execute('SELECT user_id,enabled FROM tv_webhooks WHERE token_hash=?', (digest,)).fetchone()
        return (int(row[0]), bool(row[1])) if row else (None, False)
    def claim_tv_event(self, uid, event_id, now):
        self.db.execute('DELETE FROM tv_seen_events WHERE seen_at < ?', (int(now) - 86400,))
        cur = self.db.execute('INSERT OR IGNORE INTO tv_seen_events(user_id,event_id,seen_at) VALUES(?,?,?)', (int(uid), str(event_id), int(now)))
        self.db.commit(); return cur.rowcount == 1

class TenantManager:
    def __init__(self, settings):
        self.settings=settings
        self.store=AccountStore(settings.encryption_key)
        self.owners=set(settings.admins)
        for uid in self.owners: self.store.allow(uid)
        self.apps={}
    def is_allowed(self, uid): return int(uid) in self.owners or self.store.allowed(uid)
    async def get_app(self, uid):
        uid=int(uid)
        if uid not in self.apps:
            os.makedirs('data/users', exist_ok=True)
            s=self.settings.model_copy(update={'state_file':f'data/users/{uid}_state.json','database_url':f'sqlite+aiosqlite:///data/users/{uid}.db','admin_ids':str(uid)})
            app=App(s, user_id=uid, user_keys={m:self.store.keys(uid,m) for m in ('demo','live')})
            await app.start()
            self.apps[uid]=app
            import asyncio
            app._tenant_task=asyncio.create_task(app.loop())
        return self.apps[uid]
    async def get_tv_app(self, uid):
        if not self.is_allowed(uid): return None
        return await self.get_app(uid)
    async def set_keys(self, uid, mode, key, secret):
        from exchanges.client import Exchange
        probe=Exchange(self.settings.exchange, key, secret, demo=(mode=='demo'))
        try:
            await probe.load()
            await probe.ex.fetch_balance()
        finally:
            await probe.close()
        app=self.apps.get(int(uid))
        if app and app.state.mode==mode and app.state.positions:
            raise RuntimeError('Спочатку закрийте відкриті позиції цього режиму, потім змінюйте API-ключі')
        self.store.save_keys(uid,mode,key,secret)
        if app:
            app.user_keys[mode]=(key,secret)
            if app.state.mode==mode:
                app.state.auto_trade=False
                await app.build_executor()
                app.save()
    async def close(self):
        import asyncio
        tasks=[]
        for app in self.apps.values():
            try:
                if app._tenant_task:
                    app._tenant_task.cancel(); tasks.append(app._tenant_task)
                app.save()
                if app.tr: await app.tr.close()
                await app.public.close(); await app.bot.session.close(); await app.db.engine.dispose()
            except Exception: pass
        if tasks: await asyncio.gather(*tasks, return_exceptions=True)
        self.store.db.close()
