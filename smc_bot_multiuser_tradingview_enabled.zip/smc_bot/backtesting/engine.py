"""Event-driven бектест на 5m історії. Старші ТФ — ресемплінг лише ЗАКРИТИХ свічок (без look-ahead).
Модель виконання: вхід по close сигнальної свічки + slippage, комісії taker на кожну ногу, SL перевіряється першим."""
from __future__ import annotations
import math
import numpy as np
import pandas as pd
from market_data.timeframes import TF_MS
from strategies.smc_breakout import Params, analyze

SPLIT = (0.5, 0.3, 0.2)


def resample(df5: pd.DataFrame, tf: str) -> pd.DataFrame:
    if tf == "5m": return df5.reset_index(drop=True)
    idx = pd.to_datetime(df5["ts"], unit="ms")
    g = df5.set_index(idx).resample({"15m": "15min", "30m": "30min", "1h": "1h", "4h": "4h", "1d": "1D"}[tf], label="left", closed="left")
    out = g.agg({"ts": "first", "open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna()
    # ts бару = початок бакета
    out["ts"] = ((out.index - pd.Timestamp("1970-01-01")) // pd.Timedelta("1ms")).astype("int64")
    return out.reset_index(drop=True)


def metrics(pnls, fees, start_eq):
    if not pnls: return {"trades": 0}
    w = [x for x in pnls if x > 0]; l = [x for x in pnls if x <= 0]
    eq = start_eq; peak = eq; dd = 0.0
    for x in pnls:
        eq += x; peak = max(peak, eq); dd = max(dd, (peak - eq) / peak * 100)
    rets = np.array(pnls) / start_eq
    sharpe = float(rets.mean() / rets.std() * math.sqrt(len(rets))) if len(rets) > 1 and rets.std() > 0 else 0.0
    return {"trades": len(pnls), "win_rate_%": round(len(w) / len(pnls) * 100, 1),
            "profit_factor": round(sum(w) / abs(sum(l)), 2) if l and sum(l) else None,
            "net_profit": round(sum(pnls), 2), "max_drawdown_%": round(dd, 2),
            "avg_win": round(sum(w) / len(w), 2) if w else 0, "avg_loss": round(sum(l) / len(l), 2) if l else 0,
            "expectancy": round(sum(pnls) / len(pnls), 3), "fees": round(fees, 2), "sharpe_per_trade_scaled": round(sharpe, 2)}


def run(df5: pd.DataFrame, symbol="TEST", p: Params = Params(), equity=1000.0, risk_pct=0.5,
        fee=0.0005, slip=0.0002, warmup_days=45, max_hold=288, step=1):
    p = Params(**{**p.__dict__, "fee": fee, "slip": slip})
    if p.confirm_tf == "1m":
        raise ValueError("Backtest використовує 5m OHLCV і не може достовірно тестувати confirm_tf=1m. Надайте окремі 1m дані або використайте 5m.")
    tfs = ["1d", "4h", "1h", p.trigger_tf]; full = {tf: resample(df5, tf) for tf in tfs}; full["5m"] = df5.reset_index(drop=True)
    ts5 = df5["ts"].to_numpy(); hi = df5["high"].to_numpy(); lo = df5["low"].to_numpy(); cl = df5["close"].to_numpy()
    lim = {"1d": 120, "4h": 200, "1h": 200, p.trigger_tf: 300, "5m": 300}
    pnls, fees_total, seen, trades = [], 0.0, set(), []
    i = max(int(warmup_days * 288), 300); eq = equity
    while i < len(df5) - 2:
        t_close = ts5[i] + TF_MS["5m"]; fr = {}
        for tf, d in full.items():
            n = int(np.searchsorted(d["ts"].to_numpy(), t_close - TF_MS[tf], side="right"))   # лише завершені бари
            fr[tf] = d.iloc[max(0, n - lim[tf]):n].reset_index(drop=True)
        sig, _ = analyze(symbol, fr, p) if i % step == 0 else (None, [])
        if not sig or sig.key in seen: i += 1; continue
        seen.add(sig.key); d = 1 if sig.direction == "LONG" else -1
        entry = sig.entry * (1 + slip * d); dist = abs(entry - sig.sl)
        unit = dist + entry * 2 * fee + entry * 2 * slip
        qty = eq * risk_pct / 100 / unit
        if qty * entry > eq * 3 * 0.9: qty = eq * 3 * 0.9 / entry
        tps = [sig.tp1, sig.tp2, sig.tp3]; rem = qty; sl = sig.sl; done = 0
        pnl = -entry * qty * fee; fee_sum = entry * qty * fee
        end = min(i + max_hold, len(df5) - 1); j = i + 1; closed = False
        while j <= end and rem > 1e-12:
            if (lo[j] <= sl) if d == 1 else (hi[j] >= sl):
                px = sl * (1 - slip * d); pnl += (px - entry) * d * rem - px * rem * fee; fee_sum += px * rem * fee; rem = 0; closed = True; break
            while done < 3 and ((hi[j] >= tps[done]) if d == 1 else (lo[j] <= tps[done])):
                q = rem if done == 2 else qty * SPLIT[done]; q = min(q, rem); px = tps[done]
                pnl += (px - entry) * d * q - px * q * fee; fee_sum += px * q * fee; rem -= q; done += 1
                if done == 1: sl = entry
            j += 1
        if rem > 1e-12:
            px = cl[min(j, len(cl) - 1)]; pnl += (px - entry) * d * rem - px * rem * fee; fee_sum += px * rem * fee
        eq += pnl; pnls.append(pnl); fees_total += fee_sum
        trades.append({"time": int(ts5[i]), "dir": sig.direction, "pnl": pnl})
        i = max(j, i + 1)    # одна угода одночасно
    return metrics(pnls, fees_total, equity), trades


def walk_forward(df5, windows=4, **kw):
    """Послідовні out-of-sample вікна з ФІКСОВАНИМИ параметрами (оптимізації параметрів немає)."""
    n = len(df5); w = n // windows; res = []
    for k in range(windows):
        part = df5.iloc[max(0, k * w - 45 * 288):(k + 1) * w].reset_index(drop=True)
        if len(part) > 46 * 288: res.append(run(part, **kw)[0])
    return res
