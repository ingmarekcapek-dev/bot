"""python -m backtesting.run BTC/USDT:USDT --days 90 --exchange binance [--windows 3]"""
import argparse, asyncio, json
from exchanges.client import Exchange
from backtesting.engine import run, walk_forward


async def main():
    a = argparse.ArgumentParser(); a.add_argument("symbol"); a.add_argument("--days", type=int, default=90)
    a.add_argument("--exchange", default="binance"); a.add_argument("--windows", type=int, default=0)
    a = a.parse_args(); ex = Exchange(a.exchange); await ex.load()
    try: df = await ex.history(a.symbol, "5m", a.days)
    finally: await ex.close()
    print(f"Свічок 5m: {len(df)}")
    if a.windows: [print(i, json.dumps(m)) for i, m in enumerate(walk_forward(df, a.windows))]
    else: print(json.dumps(run(df, a.symbol)[0], indent=1, ensure_ascii=False))

asyncio.run(main())
