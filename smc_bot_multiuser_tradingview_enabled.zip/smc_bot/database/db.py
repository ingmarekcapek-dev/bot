from __future__ import annotations
import json, os, time
from sqlalchemy import String, Float, Integer, Text, BigInteger, select
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase): pass


class SignalRow(Base):
    __tablename__ = "signals"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[int] = mapped_column(BigInteger)
    key: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    symbol: Mapped[str] = mapped_column(String(32))
    direction: Mapped[str] = mapped_column(String(8))
    confidence: Mapped[int] = mapped_column(Integer)
    payload: Mapped[str] = mapped_column(Text)
    executed: Mapped[int] = mapped_column(Integer, default=0)


class TradeRow(Base):
    __tablename__ = "trades"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)
    mode: Mapped[str] = mapped_column(String(8))
    symbol: Mapped[str] = mapped_column(String(32))
    side: Mapped[str] = mapped_column(String(8))
    opened_at: Mapped[int] = mapped_column(BigInteger)
    closed_at: Mapped[int] = mapped_column(BigInteger)
    entry: Mapped[float] = mapped_column(Float)
    qty: Mapped[float] = mapped_column(Float)
    sl: Mapped[float] = mapped_column(Float)
    risk_usdt: Mapped[float] = mapped_column(Float)
    pnl: Mapped[float] = mapped_column(Float)
    fees: Mapped[float] = mapped_column(Float)
    reason: Mapped[str] = mapped_column(String(200))


class ActionLog(Base):
    __tablename__ = "action_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[int] = mapped_column(BigInteger)
    actor: Mapped[str] = mapped_column(String(40))
    action: Mapped[str] = mapped_column(String(80))
    details: Mapped[str] = mapped_column(Text, default="")


class Database:
    def __init__(self, url: str):
        if url.startswith("sqlite"):
            os.makedirs("data", exist_ok=True)
        self.engine = create_async_engine(url)
        self.S = async_sessionmaker(self.engine, expire_on_commit=False)

    async def init(self):
        async with self.engine.begin() as c: await c.run_sync(Base.metadata.create_all)

    async def log(self, actor, action, details=""):
        async with self.S() as s:
            s.add(ActionLog(ts=int(time.time() * 1000), actor=str(actor), action=action, details=str(details)[:2000])); await s.commit()

    async def signal_exists(self, key) -> bool:
        # A failed attempt (executed=0) must not permanently suppress a valid signal.
        async with self.S() as s:
            return (await s.execute(select(SignalRow.id).where(SignalRow.key == key))).first() is not None

    async def save_signal(self, sig, executed: bool):
        async with self.S() as s:
            row = (await s.execute(select(SignalRow).where(SignalRow.key == sig.key))).scalar_one_or_none()
            payload = json.dumps({"entry": sig.entry, "sl": sig.sl,
                                  "tp": [sig.tp1, sig.tp2, sig.tp3], "reasons": sig.reasons})
            if row is None:
                row = SignalRow(ts=int(time.time() * 1000), key=sig.key, symbol=sig.symbol,
                                direction=sig.direction, confidence=sig.confidence,
                                executed=int(executed), payload=payload)
                s.add(row)
            else:
                row.ts = int(time.time() * 1000)
                row.confidence = sig.confidence
                row.executed = int(executed)
                row.payload = payload
            await s.commit()

    async def save_trade(self, pos, pnl, reason):
        async with self.S() as s:
            row = await s.get(TradeRow, pos.id)
            values = dict(mode=pos.mode, symbol=pos.symbol, side=pos.side, opened_at=pos.opened_at,
                          closed_at=int(time.time() * 1000), entry=pos.entry, qty=pos.initial_qty,
                          sl=pos.entry_sl, risk_usdt=pos.risk_usdt, pnl=pnl,
                          fees=pos.fees, reason=reason[:200])
            if row is None:
                s.add(TradeRow(id=pos.id, **values))
            else:
                for key, value in values.items(): setattr(row, key, value)
            await s.commit()

    async def trades(self, limit=10, mode=None):
        async with self.S() as s:
            q = select(TradeRow).order_by(TradeRow.closed_at.desc())
            if mode: q = q.where(TradeRow.mode == mode)
            return list((await s.execute(q.limit(limit))).scalars())
