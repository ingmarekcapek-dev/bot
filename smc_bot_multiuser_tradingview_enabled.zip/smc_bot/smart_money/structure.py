"""Ринкова структура, FVG, ліквідність. Усі функції працюють лише на ЗАКРИТИХ свічках;
свінг підтверджується з запізненням у n барів (немає look-ahead)."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd


@dataclass
class Swing:
    idx: int
    price: float
    kind: str        # 'H' | 'L'
    confirmed: int   # індекс свічки, з якої свінг відомий


@dataclass
class FVG:
    idx: int         # свічка, на якій гап став відомий
    kind: str        # 'bull' | 'bear'
    lo: float
    hi: float


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    h, l, c = df["high"], df["low"], df["close"]
    pc = c.shift(1)
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def find_swings(df: pd.DataFrame, n: int = 3) -> list[Swing]:
    hi = df["high"].to_numpy(); lo = df["low"].to_numpy(); out: list[Swing] = []
    for i in range(n, len(df) - n):
        if hi[i] > hi[i - n:i].max() and hi[i] >= hi[i + 1:i + n + 1].max():
            out.append(Swing(i, float(hi[i]), "H", i + n))
        if lo[i] < lo[i - n:i].min() and lo[i] <= lo[i + 1:i + n + 1].min():
            out.append(Swing(i, float(lo[i]), "L", i + n))
    out.sort(key=lambda s: (s.confirmed, s.idx))
    return out


def confirmed(swings: list[Swing], upto: int) -> list[Swing]:
    return [s for s in swings if s.confirmed <= upto]


def label_swings(swings: list[Swing]) -> list[tuple[Swing, str]]:
    """HH / LH / HL / LL відносно попереднього свінгу того ж типу."""
    last: dict[str, float] = {}; out = []
    for s in swings:
        prev = last.get(s.kind)
        if prev is not None:
            lab = ("HH" if s.price > prev else "LH") if s.kind == "H" else ("HL" if s.price > prev else "LL")
            out.append((s, lab))
        last[s.kind] = s.price
    return out


def trend(swings: list[Swing]) -> int:
    """+1 бичачий (HH+HL), -1 ведмежий (LH+LL), 0 рейндж."""
    H = [s for s in swings if s.kind == "H"][-2:]
    L = [s for s in swings if s.kind == "L"][-2:]
    if len(H) < 2 or len(L) < 2:
        return 0
    if H[1].price > H[0].price and L[1].price > L[0].price:
        return 1
    if H[1].price < H[0].price and L[1].price < L[0].price:
        return -1
    return 0


def is_displacement(df: pd.DataFrame, i: int, atr_arr: np.ndarray, mult: float) -> bool:
    if i < 0 or i >= len(df) or np.isnan(atr_arr[i]):
        return False
    body = abs(df["close"].iat[i] - df["open"].iat[i])
    return bool(body >= mult * atr_arr[i])


def structure_break(df, swings, i, direction, atr_arr, disp_mult):
    """Закриття свічки i за останнім підтвердженим свінгом (відомим на i-1).
    BOS = за трендом, CHoCH = проти тренду, MSS = CHoCH + displacement."""
    known = confirmed(swings, i - 1)
    tr = trend(known)
    pool = [s for s in known if s.kind == ("H" if direction == 1 else "L")]
    if not pool:
        return None
    lvl = pool[-1].price
    c = df["close"].iat[i]
    if (direction == 1 and not c > lvl) or (direction == -1 and not c < lvl):
        return None
    kind = "CHoCH" if tr == -direction else "BOS"
    if kind == "CHoCH" and is_displacement(df, i, atr_arr, disp_mult):
        kind = "MSS"
    return {"kind": kind, "level": float(lvl), "idx": i, "trend_before": tr}


def find_fvgs(df: pd.DataFrame) -> list[FVG]:
    h = df["high"].to_numpy(); l = df["low"].to_numpy(); out = []
    for i in range(2, len(df)):
        if l[i] > h[i - 2]:
            out.append(FVG(i, "bull", float(h[i - 2]), float(l[i])))
        elif h[i] < l[i - 2]:
            out.append(FVG(i, "bear", float(h[i]), float(l[i - 2])))
    return out


def equal_levels(swings: list[Swing], kind: str, tol: float) -> list[float]:
    """Equal Highs / Equal Lows: кластери свінгів в межах tol (абсолютна ціна)."""
    pts = sorted(s.price for s in swings if s.kind == kind)
    out = []
    for a, b in zip(pts, pts[1:]):
        if abs(a - b) <= tol:
            out.append((a + b) / 2)
    return out


def liquidity_swept(df, swings, direction: int, start: int, end: int) -> bool:
    """direction=+1: знято sell-side (low нижче попереднього свінг-лоу, закриття назад вище) -> стоп-хант перед лонгом.
    direction=-1: знято buy-side."""
    start = max(start, 1)
    for t in range(start, min(end, len(df) - 1) + 1):
        known = confirmed(swings, t - 1)
        if direction == 1:
            pool = [s for s in known if s.kind == "L"]
            if pool and df["low"].iat[t] < pool[-1].price < df["close"].iat[t]:
                return True
        else:
            pool = [s for s in known if s.kind == "H"]
            if pool and df["high"].iat[t] > pool[-1].price > df["close"].iat[t]:
                return True
    return False


def next_liquidity(df, swings, price: float, d: int):
    """Найближчий незнятий свінг у напрямку угоди (ціль для TP3)."""
    best = None
    for s in swings:
        if d == 1 and s.kind == "H" and s.price > price:
            later = df["high"].iloc[s.idx + 1:].max() if s.idx + 1 < len(df) else -np.inf
            if later <= s.price and (best is None or s.price < best):
                best = s.price
        if d == -1 and s.kind == "L" and s.price < price:
            later = df["low"].iloc[s.idx + 1:].min() if s.idx + 1 < len(df) else np.inf
            if later >= s.price and (best is None or s.price > best):
                best = s.price
    return best


def premium_discount(df: pd.DataFrame, price: float, lookback: int = 60) -> float:
    """0..1: <0.5 Discount, >0.5 Premium, 0.5 = Equilibrium."""
    w = df.iloc[-lookback:]
    hi, lo = w["high"].max(), w["low"].min()
    return float((price - lo) / (hi - lo)) if hi > lo else 0.5
