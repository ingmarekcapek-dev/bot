from __future__ import annotations
import html, logging
from aiogram import Router, F, BaseMiddleware
from aiogram.filters import Command, CommandStart
from aiogram.types import (Message, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton,
                           InlineKeyboardMarkup, InlineKeyboardButton)

log = logging.getLogger("tg")
B = dict(start="▶️ START BOT", stop="⏹ STOP BOT", auto_on="🤖 Автоторгівля ON", auto_off="🚫 Автоторгівля OFF",
         bal="💰 Баланс", pos="📊 Позиції", hist="📜 Історія", stat="📈 Статистика", risk="⚙️ Ризик",
         pairs="🪙 Пари", tf="⏱ Таймфрейми", lev="📐 Плече", close="❌ Закрити позиції",
         kill="🛑 ЕКСТРЕНА ЗУПИНКА", mode="🧪 DEMO / LIVE", status="ℹ️ Статус", api="🔑 API-ключі")
PAIRS = [f"{x}/USDT:USDT" for x in ("BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "ADA", "LINK")]


def menu():
    r = [[B["start"], B["stop"]], [B["auto_on"], B["auto_off"]], [B["bal"], B["pos"]], [B["hist"], B["stat"]],
         [B["risk"], B["pairs"]], [B["tf"], B["lev"]], [B["close"], B["kill"]], [B["mode"], B["status"]], [B["api"]]]
    return ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text=t) for t in row] for row in r], resize_keyboard=True)


def ikb(rows): return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, callback_data=d) for t, d in row] for row in rows])


class Auth(BaseMiddleware):
    def __init__(self, manager): self.manager = manager
    async def __call__(self, handler, event, data):
        u = data.get("event_from_user")
        if u is None or not self.manager.is_allowed(u.id):
            if isinstance(event, Message): await event.answer("⛔ Доступ закритий. Попросіть власника додати ваш Telegram ID.")
            return
        if isinstance(event, (Message, CallbackQuery)):
            chat = event.chat if isinstance(event, Message) else event.message.chat
            if chat.type != "private":
                if isinstance(event, Message): await event.answer("З міркувань безпеки використовуйте бота лише в особистому чаті.")
                return
        data["app"] = await self.manager.get_app(u.id)
        data["tenant_manager"] = self.manager
        return await handler(event, data)


def status_text(app):
    st = app.state
    return (f"<b>Статус</b>\nРежим: <b>{st.mode.upper()}</b> ({app.s.exchange})\nБот: {'🟢 працює' if st.running else '⚪️ зупинено'}\n"
            f"Автоторгівля: {'ON' if st.auto_trade else 'OFF'}\nKill Switch: {'🛑 АКТИВНИЙ' if st.kill_switch else 'ні'}\n"
            f"Ризик/угоду: {st.risk_pct}% (макс {st.max_risk_pct}%)\nПлече: {st.leverage}x\nПари: {', '.join(s.split('/')[0] for s in st.symbols)}\n"
            f"ТФ: 1D/4H/1H + {st.trigger_tf} (зони) + {st.confirm_tf} (вхід)\nПозицій: {len(st.positions)}/{st.max_positions}\n"
            f"Збитків поспіль: {st.consecutive_losses}/{st.max_consec_losses}\nЛіміти: день {st.daily_dd_pct}% / тиждень {st.weekly_dd_pct}%\n"
            f"Помилки API: {app.api_errors}")


def stats_text(trades):
    if not trades: return "Закритих угод ще немає."
    pn = [t.pnl for t in reversed(trades)]; w = [x for x in pn if x > 0]; l = [x for x in pn if x <= 0]
    eq = peak = dd = 0.0
    for x in pn:
        eq += x; peak = max(peak, eq); dd = max(dd, peak - eq)
    pf = (sum(w) / abs(sum(l))) if l and sum(l) else float("inf")
    return (f"<b>Статистика</b> ({len(pn)} угод)\nNet PnL: {sum(pn):+.2f} USDT\nWin rate: {len(w)/len(pn)*100:.1f}%\n"
            f"Profit factor: {pf:.2f}\nСер. прибуток: {sum(w)/len(w) if w else 0:.2f}\nСер. збиток: {sum(l)/len(l) if l else 0:.2f}\n"
            f"Expectancy: {sum(pn)/len(pn):+.2f}\nКомісії: {sum(t.fees for t in trades):.2f}\nМакс. просадка: {dd:.2f}")


def build_router(manager) -> Router:
    r = Router(); r.message.outer_middleware(Auth(manager)); r.callback_query.outer_middleware(Auth(manager))
    pending_api = {}

    @r.message(CommandStart())
    async def start(m: Message, app):
        await m.answer("Smart Money Futures Bot. Керуйте кнопками нижче.\nДля друзів: власник додає доступ командою /adduser TELEGRAM_ID.\n⚠️ Прибутковість не гарантована. Спершу тестуйте у PAPER/DEMO.", reply_markup=menu())
        await m.answer(status_text(app), parse_mode="HTML")

    @r.message(Command("tv"))
    async def tv_command(m: Message, tenant_manager):
        parts = (m.text or "").split()
        uid = m.from_user.id
        if len(parts) == 1 or parts[1].lower() == "status":
            token, enabled = tenant_manager.store.tv_status(uid)
            if not token:
                return await m.answer("TradingView ще не налаштований. Створіть персональний URL командою /tv generate")
            state = "увімкнений" if enabled else "вимкнений"
            return await m.answer(f"TradingView: {state}\nWebhook URL: /tv/{token}\nКеруйте: /tv on або /tv off\nНе передавайте URL іншим — це ваш персональний секрет.")
        action = parts[1].lower()
        if action == "generate":
            token = tenant_manager.store.create_tv_token(uid)
            await m.answer(f"✅ Персональний TradingView URL створено:\n/tv/{token}\n\nУ TradingView використайте повний URL: https://ВАШ-ДОМЕН/tv/{token}\nПовідомлення alert: {{\"symbol\":\"{{{{ticker}}}}\",\"action\":\"buy\",\"tf\":\"{{{{interval}}}}\",\"id\":\"{{{{ticker}}}}-{{{{timenow}}}}\"}}\nЗберігайте URL у таємниці. Новий токен замінює попередній.")
        elif action in ("on", "off"):
            token, _ = tenant_manager.store.tv_status(uid)
            if not token: return await m.answer("Спочатку створіть URL: /tv generate")
            tenant_manager.store.set_tv_enabled(uid, action == "on")
            await m.answer("TradingView webhook увімкнено." if action == "on" else "TradingView webhook вимкнено.")
        else:
            await m.answer("Команди: /tv status, /tv generate, /tv on, /tv off")

    @r.message(Command("cancel"))
    async def cancel_api(m: Message):
        pending_api.pop(m.from_user.id, None)
        await m.answer("Введення API-ключів скасовано.")

    @r.message(Command("adduser"))
    async def adduser(m: Message, tenant_manager):
        if m.from_user.id not in tenant_manager.owners: return await m.answer("Лише власник може додавати користувачів.")
        parts=(m.text or "").split()
        if len(parts)!=2 or not parts[1].isdigit(): return await m.answer("Формат: /adduser TELEGRAM_ID")
        uid=int(parts[1]); tenant_manager.store.allow(uid)
        await m.answer(f"✅ Доступ надано Telegram ID {uid}. Користувач може відкрити бота через /start.")

    @r.message(Command("removeuser"))
    async def removeuser(m: Message, tenant_manager):
        if m.from_user.id not in tenant_manager.owners: return await m.answer("Лише власник може забирати доступ.")
        parts=(m.text or "").split()
        if len(parts)!=2 or not parts[1].isdigit(): return await m.answer("Формат: /removeuser TELEGRAM_ID")
        uid=int(parts[1])
        if uid in tenant_manager.owners: return await m.answer("Не можна видалити власника.")
        existing=tenant_manager.apps.get(uid)
        if existing and existing.state.positions:
            return await m.answer("У користувача є відкриті позиції. Спочатку закрийте їх, щоб не залишити акаунт без супроводу.")
        tenant_manager.store.revoke(uid)
        app=tenant_manager.apps.pop(uid, None)
        if app:
            if app._tenant_task: app._tenant_task.cancel()
            if app.tr: await app.tr.close()
            await app.public.close(); await app.bot.session.close(); await app.db.engine.dispose()
        await m.answer(f"✅ Доступ для {uid} забрано. Його API-ключі видалено з бази.")

    @r.message(F.text == B["api"])
    async def api_menu(m: Message, tenant_manager):
        uid=m.from_user.id
        await m.answer("🔐 Підключення особистого Binance API. Створіть ключі з дозволом Futures/читання/торгівля, але БЕЗ Withdraw. Виберіть середовище:",
            reply_markup=ikb([[('DEMO / Testnet','api:demo'),('LIVE / Реальні кошти','api:live')],[('Видалити DEMO','api:del_demo'),('Видалити LIVE','api:del_live')]]))

    @r.callback_query(F.data.startswith("api:"))
    async def api_action(c: CallbackQuery, tenant_manager):
        action=c.data[4:]; uid=c.from_user.id
        if action in ('demo','live'):
            pending_api[uid]={'mode':action,'step':'key'}
            await c.message.answer(f"Надішліть API KEY для режиму {action.upper()} окремим повідомленням. Не надсилайте його в групу.")
        elif action in ('del_demo','del_live'):
            mode=action[4:]; account=tenant_manager.apps.get(uid)
            if account and account.state.mode==mode and account.state.positions:
                await c.message.answer("Спочатку закрийте всі позиції цього режиму, потім видаляйте ключі.")
                return await c.answer()
            tenant_manager.store.db.execute('DELETE FROM api_accounts WHERE user_id=? AND mode=?',(uid,mode)); tenant_manager.store.db.commit()
            if account:
                account.user_keys[mode]=('', '')
                if account.state.mode==mode:
                    account.state.auto_trade=False
                    await account.build_executor()
            await c.message.answer(f"Ключі {mode.upper()} видалено.")
        await c.answer()


    @r.message(F.text == B["status"])
    @r.message(Command("status"))
    async def status(m: Message, app): await m.answer(status_text(app), parse_mode="HTML")

    @r.message(F.text == B["start"])
    async def start_bot(m: Message, app):
        app.state.running = True; app.save(); await app.db.log(m.from_user.id, "start_bot")
        await m.answer("🟢 Бот запущено: сканування й супровід увімкнено. Автоторгівля — окремою кнопкою.")

    @r.message(F.text == B["stop"])
    async def stop_bot(m: Message, app):
        app.state.running = False; app.save(); await app.db.log(m.from_user.id, "stop_bot")
        await m.answer("⏹ Сканування зупинено. Відкриті позиції й надалі супроводжуються (SL/TP на біржі).")

    @r.message(F.text == B["auto_on"])
    async def auto_on(m: Message, app):
        if app.state.kill_switch: return await m.answer("🛑 Kill Switch активний. Спершу /killoff")
        app.state.auto_trade = True; app.save(); await app.db.log(m.from_user.id, "auto_on", app.state.mode)
        await m.answer(f"🤖 Автоторгівля ON ({app.state.mode.upper()}). Не забудьте START BOT.")

    @r.message(F.text == B["auto_off"])
    async def auto_off(m: Message, app):
        app.state.auto_trade = False; app.save(); await app.db.log(m.from_user.id, "auto_off")
        await m.answer("🚫 Автоторгівля OFF: бот лише надсилає сигнали.")

    @r.message(F.text == B["bal"])
    async def bal(m: Message, app):
        try: eq = await app.executor.equity()
        except Exception as e: return await m.answer(f"Помилка біржі: {html.escape(str(e))}", parse_mode=None)
        st = app.state; d = eq - st.day_start_equity if st.day_start_equity else 0
        await m.answer(f"💰 Баланс [{st.mode.upper()}]: <b>{eq:.2f} USDT</b>\nЗа день: {d:+.2f}", parse_mode="HTML")

    @r.message(F.text == B["pos"])
    async def positions(m: Message, app):
        if not app.state.positions: return await m.answer("Відкритих позицій немає.")
        for p in app.state.positions:
            px = app.executor.last_px.get(p.symbol, p.entry); u = (px - p.entry) * p.d * p.qty * p.cs
            await m.answer(f"<b>{p.symbol}</b> {p.side.upper()} [{p.mode}]\nВхід {p.entry:.6g} | Зараз {px:.6g}\nQty {p.qty} | SL {p.sl:.6g}\n"
                           f"TP: {', '.join(f'{t:.6g}' for t,_ in p.legs)} (виконано {p.legs_done})\n{'🟢' if u >= 0 else '🔴'} Нерелізований PnL: <b>{u:+.2f} USDT</b> ({u / p.risk_usdt if p.risk_usdt else 0:+.2f}R)", parse_mode="HTML")

    @r.message(F.text == B["hist"])
    async def hist(m: Message, app):
        t = await app.db.trades(10, app.state.mode)
        await m.answer("\n".join(f"{'🟢' if x.pnl >= 0 else '🔴'} {x.symbol} {x.side} {x.pnl:+.2f} USDT ({x.reason[:25]})" for x in t) or "Історія порожня.")

    @r.message(F.text == B["stat"])
    async def stat(m: Message, app): await m.answer(stats_text(await app.db.trades(1000, app.state.mode)), parse_mode="HTML")

    @r.message(F.text == B["risk"])
    async def risk(m: Message, app):
        await m.answer(f"Ризик на угоду зараз {app.state.risk_pct}% (макс {app.state.max_risk_pct}%):",
                       reply_markup=ikb([[(f"{x}%", f"risk:{x}") for x in (0.25, 0.5, 0.75, 1.0)]]))

    @r.callback_query(F.data.startswith("risk:"))
    async def set_risk(c: CallbackQuery, app):
        try: requested = float(c.data[5:])
        except ValueError: return await c.answer("Некоректний ризик", show_alert=True)
        if requested not in (0.25, 0.5, 0.75, 1.0):
            return await c.answer("Недозволене значення ризику", show_alert=True)
        v = min(requested, app.state.max_risk_pct); app.state.risk_pct = v; app.save()
        await app.db.log(c.from_user.id, "risk", v); await c.message.edit_text(f"✅ Ризик: {v}%"); await c.answer()

    @r.message(F.text == B["lev"])
    async def lev(m: Message, app):
        await m.answer(f"Плече зараз {app.state.leverage}x:", reply_markup=ikb([[(f"{x}x", f"lev:{x}") for x in (1, 2, 3, 5, 10, 15, 20)]]))

    @r.callback_query(F.data.startswith("lev:"))
    async def set_lev(c: CallbackQuery, app):
        try: value = int(c.data[4:])
        except ValueError: return await c.answer("Некоректне плече", show_alert=True)
        if value not in (1, 2, 3, 5, 10, 15, 20):
            return await c.answer("Недозволене плече", show_alert=True)
        app.state.leverage = value; app.save(); await app.db.log(c.from_user.id, "leverage", value)
        await c.message.edit_text(f"✅ Плече: {app.state.leverage}x"); await c.answer()

    def pairs_kb(app):
        btn = [(("✅ " if s in app.state.symbols else "▫️ ") + s.split("/")[0], f"sym:{s}") for s in PAIRS]
        return ikb([btn[i:i + 4] for i in range(0, len(btn), 4)])

    @r.message(F.text == B["pairs"])
    async def pairs(m: Message, app): await m.answer("Торгові пари (натисніть для вкл/викл):", reply_markup=pairs_kb(app))

    @r.callback_query(F.data.startswith("sym:"))
    async def tog(c: CallbackQuery, app):
        s = c.data[4:]; L = app.state.symbols
        if s in L: L.remove(s)
        else: L.append(s)
        app.save(); await app.db.log(c.from_user.id, "symbols", L); await c.message.edit_reply_markup(reply_markup=pairs_kb(app)); await c.answer()

    @r.message(F.text == B["tf"])
    async def tfs(m: Message, app):
        await m.answer("Старші ТФ фіксовані: 1D (напрям), 4H (структура), 1H (локальна).\nОберіть ТФ зон і ТФ входу:",
                       reply_markup=ikb([[("Зони 15m", "tf:t:15m"), ("Зони 30m", "tf:t:30m")], [("Вхід 5m", "tf:c:5m"), ("Вхід 1m", "tf:c:1m")]]))

    @r.callback_query(F.data.startswith("tf:"))
    async def set_tf(c: CallbackQuery, app):
        try: _, k, v = c.data.split(":")
        except ValueError: return await c.answer("Некоректний таймфрейм", show_alert=True)
        if k == "t" and v in ("15m", "30m"):
            app.state.trigger_tf = v
        elif k == "c" and v in ("1m", "5m"):
            app.state.confirm_tf = v
        else:
            return await c.answer("Недозволений таймфрейм", show_alert=True)
        app.save(); await c.message.edit_text(f"✅ Зони: {app.state.trigger_tf}, вхід: {app.state.confirm_tf}"); await c.answer()

    @r.message(F.text == B["mode"])
    async def mode(m: Message, app):
        await m.answer(f"Режим: <b>{app.state.mode.upper()}</b>\nPAPER — симуляція на реальних цінах; DEMO — testnet/demo біржі; LIVE — реальні гроші.",
                       parse_mode="HTML", reply_markup=ikb([[("PAPER", "mode:paper"), ("DEMO", "mode:demo"), ("LIVE ⚠️", "mode:live")]]))

    @r.callback_query(F.data.startswith("mode:"))
    async def set_mode(c: CallbackQuery, app):
        v = c.data[5:]
        if v == "live":
            await c.message.edit_text("⚠️ <b>LIVE = реальні кошти.</b> Ви пройшли backtest, paper і demo? Підтвердити?", parse_mode="HTML",
                                      reply_markup=ikb([[("Так, LIVE", "mode:live_ok"), ("Скасувати", "mode:cancel")]])); return await c.answer()
        if v == "cancel": await c.message.edit_text("Скасовано."); return await c.answer()
        v = "live" if v == "live_ok" else v
        try:
            async with app._lock: await app.set_mode(v)
            await c.message.edit_text(f"✅ Режим: {v.upper()}. Автоторгівля вимкнена — увімкніть вручну.")
        except Exception as e: await c.message.edit_text(f"❌ {e}")
        await c.answer()

    @r.message(F.text == B["close"])
    async def close_menu(m: Message, app):
        if not app.state.positions: return await m.answer("Відкритих позицій немає.")
        rows = [[(f"Закрити {p.symbol.split('/')[0]} {p.side}", f"close:{p.id}")] for p in app.state.positions] + [[("Закрити ВСІ", "close:all")]]
        await m.answer("Ручне закриття:", reply_markup=ikb(rows))

    @r.callback_query(F.data.startswith("close:"))
    async def do_close(c: CallbackQuery, app):
        key = c.data[6:]
        async with app._lock:
            targets = list(app.state.positions) if key == "all" else [p for p in app.state.positions if p.id == key]
            for p in targets:
                try:
                    await app.executor.close_position(p, "ручне закриття")
                    if app.executor.paper:
                        await app._event({"type": "closed", "pos": p, "text": "Ручне закриття", "pnl": p.realized - p.fees})
                except Exception as e: await c.message.answer(f"❌ {p.symbol}: {e}")
        await app.db.log(c.from_user.id, "manual_close", key)
        await c.message.edit_text("Команду закриття виконано."); await c.answer()

    @r.message(F.text == B["kill"])
    async def kill(m: Message, app):
        app.state.kill_switch = True; app.state.auto_trade = False; app.save()
        await app.db.log(m.from_user.id, "KILL_SWITCH")
        await m.answer("🛑 <b>KILL SWITCH</b>: нові угоди заборонені. Відкриті позиції лишаються під захистом SL/TP на біржі.\n"
                       "Зняти: /killoff. Закрити все: кнопка «Закрити позиції».", parse_mode="HTML")

    @r.message(Command("killoff"))
    async def killoff(m: Message, app):
        app.state.kill_switch = False; app.save(); await app.db.log(m.from_user.id, "kill_off"); await m.answer("Kill Switch знято. Автоторгівлю увімкніть вручну.")

    @r.message(Command("resume"))
    async def resume(m: Message, app):
        app.state.consecutive_losses = 0; app.state.last_halt_msg = ""; app.save()
        await app.db.log(m.from_user.id, "resume"); await m.answer("Лічильник збитків скинуто. Торгівля можлива після START BOT.")

    @r.message(F.text)
    async def api_credentials(m: Message, tenant_manager):
        uid=m.from_user.id; flow=pending_api.get(uid)
        if not flow: return
        if m.chat.type!='private': return
        value=(m.text or '').strip()
        try: await m.delete()
        except Exception: pass
        if not value or len(value)>512:
            pending_api.pop(uid,None); return await m.answer("❌ Некоректне значення. Почніть підключення знову через API-ключі.")
        if flow['step']=='key':
            flow['key']=value; flow['step']='secret'
            return await m.answer("Тепер надішліть API SECRET окремим повідомленням. Повідомлення буде видалено.")
        try:
            await tenant_manager.set_keys(uid,flow['mode'],flow['key'],value)
            await m.answer(f"✅ API {flow['mode'].upper()} підключено й перевірено. Ключі зашифровані. Автоторгівля залишається вимкненою.")
        except Exception as e:
            log.warning('API verification failed for user %s: %s',uid,e)
            await m.answer("❌ Не вдалося перевірити API. Перевірте ключі, середовище DEMO/LIVE та дозволи Futures. Секрет не збережено.")
        finally: pending_api.pop(uid,None)

    return r
