from __future__ import annotations
import asyncio, time
import numpy as np
from market_data.timeframes import TF_MS

LIMITS = {"1d": 120, "4h": 200, "1h": 200, "15m": 300, "30m": 300, "5m": 300, "1m": 300}


def validate(df, tf: str):
    """Цілісність, часові мітки, актуальність."""
    if df is None or len(df) < 40: return False, f"{tf}: мало даних"
    if df[["open", "high", "low", "close", "volume"]].isna().any().any(): return False, f"{tf}: NaN"
    if (df["high"] < df["low"]).any() or (df["close"] <= 0).any(): return False, f"{tf}: некоректні OHLC"
    diffs = np.diff(df["ts"].to_numpy()[-100:])
    if (diffs != TF_MS[tf]).any(): return False, f"{tf}: пропуски/дублі свічок"
    age = time.time() * 1000 - (df["ts"].iat[-1] + TF_MS[tf])
    if age > TF_MS[tf] * 1.5 + 60_000: return False, f"{tf}: дані застарілі ({age/1000:.0f}с)"
    return True, ""


class MarketFeed:
    def __init__(self, ex):
        self.ex = ex; self.cache: dict = {}

    async def _one(self, sym, tf):
        hit = self.cache.get((sym, tf))
        if hit:   # перезапит лише коли мала закритись наступна свічка (або кеш старший за 10 хв)
            nxt_close = hit[1]["ts"].iat[-1] + 2 * TF_MS[tf]
            if time.time() * 1000 < nxt_close + 1500 and time.time() - hit[0] < 600: return hit[1]
            if time.time() - hit[0] < 5: return hit[1]
        df = await self.ex.ohlcv(sym, tf, LIMITS[tf])
        self.cache[(sym, tf)] = (time.time(), df)
        return df

    async def frames(self, sym: str, tfs: list[str]) -> dict:
        res = await asyncio.gather(*[self._one(sym, tf) for tf in tfs])
        return dict(zip(tfs, res))

    @staticmethod
    def validate_all(frames: dict):
        for tf, df in frames.items():
            ok, why = validate(df, tf)
            if not ok: return False, why
        return True, ""
