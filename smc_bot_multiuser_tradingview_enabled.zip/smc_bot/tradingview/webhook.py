"""Multi-user TradingView webhook. Each user has a unique secret URL token."""
from __future__ import annotations
import logging, time
from aiohttp import web

log = logging.getLogger("tv")

def norm(sym: str) -> str:
    s = sym.upper().replace(".P", "").replace("PERP", "")
    if "/" in s: return s
    return f"{s[:-4]}/USDT:USDT" if s.endswith("USDT") else s

async def start(manager, port: int, allowed_ips: set[str]):
    async def handler(req: web.Request):
        ip = req.remote or ""
        if allowed_ips and ip not in allowed_ips:
            log.warning("TV: IP %s не в whitelist", ip); return web.Response(status=403)
        token = req.match_info.get("token", "")
        uid, enabled = manager.store.tv_owner(token)
        if uid is None or not enabled:
            return web.Response(status=404)
        if not manager.is_allowed(uid):
            return web.Response(status=403)
        try: data = await req.json()
        except Exception: return web.Response(status=400)
        if not isinstance(data, dict): return web.Response(status=400)
        symbol = str(data.get("symbol", "")).strip()
        side = {"buy": "LONG", "sell": "SHORT"}.get(str(data.get("action", "")).lower())
        mid = str(data.get("id", "")).strip()
        if not symbol or len(symbol) > 40 or not side or not mid or len(mid) > 160:
            return web.Response(status=400, text="invalid payload")
        now = time.time()
        if not manager.store.claim_tv_event(uid, mid, now): return web.Response(status=200, text="dup")
        app = await manager.get_tv_app(uid)
        if app is None: return web.Response(status=403)
        app.tv_hints[norm(symbol)] = (side, now)
        await app.db.log("tradingview", "webhook", f"{symbol} {side} {str(data.get('tf', ''))[:20]}")
        return web.Response(text="ok")
    web_app = web.Application(client_max_size=16 * 1024)
    web_app.router.add_post("/tv/{token}", handler)
    runner = web.AppRunner(web_app, access_log=None); await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", port).start()
    log.info("Multi-user TradingView webhook слухає :%s/tv/{token}", port)
    return runner
