"""Стратегія: пробиття Order Block закриттям -> displacement -> BOS/CHoCH -> ретест -> FVG/ліквідність/обсяг -> RR.
Реплей-підхід: кожен цикл перераховує стан із закритих свічок; дедуплікація за Signal.key."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import numpy as np
from smart_money.structure import (atr, find_swings, trend, structure_break, is_displacement, find_fvgs,
                                   liquidity_swept, next_liquidity, premium_discount, equal_levels)
from order_blocks.detector import detect_order_blocks, OrderBlock
from market_data.timeframes import TF_MS


@dataclass
class Params:
    trigger_tf: str = "15m"
    confirm_tf: str = "5m"
    swing_n: int = 3
    atr_len: int = 14
    disp_mult: float = 1.5
    ob_min_h_atr: float = 0.3
    ob_max_h_atr: float = 3.0
    max_break_age: int = 48          # барів trigger TF після пробиття
    retest_window: int = 12          # барів confirm TF від дотику
    max_chase_atr: float = 1.0
    sl_atr_buf: float = 0.3
    min_sl_pct: float = 0.001
    max_sl_pct: float = 0.03
    vol_mult: float = 1.2
    require_fvg: bool = False
    require_volume: bool = True
    min_rr: float = 2.0
    rr2: float = 3.0
    rr3_fallback: float = 4.0
    fee: float = 0.0005
    slip: float = 0.0002
    min_confidence: int = 60


@dataclass
class Signal:
    symbol: str
    direction: str
    entry: float
    sl: float
    tp1: float
    tp2: float
    tp3: float
    rr: float
    tf: str
    ob: OrderBlock
    structure: str
    fvg: Optional[tuple]
    confidence: int
    reasons: list = field(default_factory=list)
    key: str = ""
    atr: float = 0.0


def _tp(entry, dist, cost, rr, d):
    return entry + d * (rr * (dist + cost) + cost)   # RR з урахуванням комісій/slippage


def analyze(symbol: str, fr: dict, p: Params = Params(), tv_dir: Optional[str] = None):
    notes: list[str] = []
    for tf in ("1d", "4h", "1h", p.trigger_tf, p.confirm_tf):
        if tf not in fr or len(fr[tf]) < 40:
            return None, [f"недостатньо даних {tf}"]
    m15, m5 = fr[p.trigger_tf], fr[p.confirm_tf]
    av = atr(m15, p.atr_len).to_numpy(); last = len(m15) - 1
    if np.isnan(av[last]):
        return None, ["ATR не готовий"]
    sw = find_swings(m15, p.swing_n)
    t1d = trend(find_swings(fr["1d"], 2)); t4h = trend(find_swings(fr["4h"], 3)); t1h = trend(find_swings(fr["1h"], 3))
    h1_sw = find_swings(fr["1h"], 3)
    obs = detect_order_blocks(m15, av, p.disp_mult, 5, p.ob_min_h_atr, p.ob_max_h_atr)
    cands = [o for o in obs if o.broken_idx is not None and last - o.broken_idx <= p.max_break_age]
    for ob in sorted(cands, key=lambda o: -o.broken_idx):
        sig = _evaluate(symbol, fr, p, ob, m15, m5, av, sw, h1_sw, (t1d, t4h, t1h), tv_dir, notes)
        if sig:
            return sig, notes
    return None, notes[-5:]


def _evaluate(symbol, fr, p, ob, m15, m5, av, sw, h1_sw, trends, tv_dir, notes):
    long = ob.kind == "bearish"            # пробиття Bearish OB вгору -> LONG
    d = 1 if long else -1
    side = "LONG" if long else "SHORT"
    b = ob.broken_idx; last = len(m15) - 1
    tag = f"{side} OB@{ob.time}"
    ev = None
    for k in (b, b + 1):
        if k <= last:
            ev = structure_break(m15, sw, k, d, av, p.disp_mult)
            if ev: break
    if not ev:
        notes.append(f"{tag}: немає BOS/CHoCH"); return None
    if not any(is_displacement(m15, k, av, p.disp_mult) for k in (b, b + 1) if k <= last):
        notes.append(f"{tag}: немає displacement"); return None
    t1d, t4h, t1h = trends
    opp = sum(1 for t in (t1d, t4h) if t == -d)
    penalty = 0
    if opp == 2:
        notes.append(f"{tag}: проти 1D і 4H"); return None
    if opp == 1:
        if not (t1h == d and ev["kind"] in ("CHoCH", "MSS")):
            notes.append(f"{tag}: проти старшого ТФ без контртрендової моделі"); return None
        penalty = 10
    # --- ретест на confirm TF ---
    t_break = int(m15["ts"].iat[b]) + TF_MS[p.trigger_tf]
    s5 = m5[m5["ts"] >= t_break].reset_index(drop=True)
    if len(s5) == 0:
        notes.append(f"{tag}: чекаємо ретест"); return None
    o5, h5, l5, c5 = (s5[x].to_numpy() for x in ("open", "high", "low", "close"))
    if long:
        if (c5 < ob.lo).any(): notes.append(f"{tag}: зона втрачена"); return None
        touched = np.where(l5 <= ob.hi)[0]
    else:
        if (c5 > ob.hi).any(): notes.append(f"{tag}: зона втрачена"); return None
        touched = np.where(h5 >= ob.lo)[0]
    if len(touched) == 0:
        notes.append(f"{tag}: чекаємо ретест"); return None
    t0 = int(touched[0]); L = len(s5) - 1
    if L - t0 > p.retest_window:
        notes.append(f"{tag}: ретест застарів"); return None
    ok_c = (c5[L] > ob.hi and c5[L] > o5[L]) if long else (c5[L] < ob.lo and c5[L] < o5[L])
    if not ok_c:
        notes.append(f"{tag}: немає підтвердження після ретесту"); return None
    entry = float(c5[L]); a_last = float(av[last])
    if (entry - ob.hi if long else ob.lo - entry) > p.max_chase_atr * a_last:
        notes.append(f"{tag}: ціна відійшла від зони"); return None
    # --- обсяг / FVG / ліквідність ---
    vol = m15["volume"].to_numpy()
    ref = vol[max(0, b - 20):b].mean() if b > 0 else 0
    vol_ok = ref > 0 and max(vol[b], vol[min(b + 1, last)]) >= p.vol_mult * ref
    if p.require_volume and not vol_ok:
        notes.append(f"{tag}: слабкий обсяг"); return None
    fv = [f for f in find_fvgs(m15) if f.kind == ("bull" if long else "bear") and (b - 1 <= f.idx <= b + 2 or f.idx == ob.disp_idx)]
    if p.require_fvg and not fv:
        notes.append(f"{tag}: немає FVG"); return None
    sweep = liquidity_swept(m15, sw, d, ob.idx - 12, b)
    pdp = premium_discount(fr["4h"], entry)
    if (long and pdp > 0.75) or (not long and pdp < 0.25):
        notes.append(f"{tag}: вхід у невигідній зоні Premium/Discount"); return None
    # --- SL / TP ---
    if long:
        sl = min(ob.lo, float(l5[t0:].min())) - p.sl_atr_buf * a_last
    else:
        sl = max(ob.hi, float(h5[t0:].max())) + p.sl_atr_buf * a_last
    dist = abs(entry - sl)
    if not (p.min_sl_pct * entry <= dist <= p.max_sl_pct * entry):
        notes.append(f"{tag}: SL-дистанція поза межами"); return None
    cost = entry * (2 * p.fee + 2 * p.slip)
    tp1 = _tp(entry, dist, cost, p.min_rr, d); tp2 = _tp(entry, dist, cost, p.rr2, d)
    liq = next_liquidity(fr["1h"], h1_sw, entry, d)
    tp3 = liq if liq is not None and (liq - tp2) * d > 0 else _tp(entry, dist, cost, p.rr3_fallback, d)
    rr = (abs(tp1 - entry) - cost) / (dist + cost)
    if rr < p.min_rr - 1e-9:
        notes.append(f"{tag}: RR {rr:.2f} < мінімуму"); return None
    # --- впевненість ---
    conf = 40 - penalty
    conf += 15 if opp == 0 and (t1d == d or t4h == d) else 5 if opp == 0 else 0
    conf += 10 if fv else 0
    conf += 10 if sweep else 0
    conf += 10 if vol_ok else 0
    conf += 10 if ((long and pdp < 0.5) or (not long and pdp > 0.5)) else 0
    conf += 5 if ev["kind"] == "MSS" else 0
    if tv_dir and tv_dir.upper() == side:
        conf += 5
    conf = int(min(conf, 95))
    if conf < p.min_confidence:
        notes.append(f"{tag}: впевненість {conf} < {p.min_confidence}"); return None
    eq = equal_levels(sw, "L" if long else "H", 0.1 * a_last)
    reasons = [f"{'Bearish' if long else 'Bullish'} OB пробито закриттям {p.trigger_tf} (breaker)",
               f"{ev['kind']} (рівень {ev['level']:.4g})", "Displacement підтверджено",
               f"Ретест зони і закриття {p.confirm_tf} за межею",
               f"Тренд 1D/4H/1H: {t1d}/{t4h}/{t1h}",
               f"Обсяг {'✓' if vol_ok else '✗'}, FVG {'✓' if fv else '✗'}, sweep ліквідності {'✓' if sweep else '✗'}",
               f"Premium/Discount: {pdp:.2f}"]
    if eq: reasons.append("Equal levels поблизу")
    return Signal(symbol, side, entry, sl, tp1, tp2, tp3, round(rr, 2), p.trigger_tf, ob, ev["kind"],
                  (fv[0].lo, fv[0].hi) if fv else None, conf, reasons, f"{symbol}:{side}:{ob.time}", a_last)
