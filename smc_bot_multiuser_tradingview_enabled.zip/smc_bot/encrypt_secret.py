"""python encrypt_secret.py  -> генерує ENCRYPTION_KEY і шифрує введений секрет."""
import getpass, sys
from cryptography.fernet import Fernet
key = sys.argv[1] if len(sys.argv) > 1 else Fernet.generate_key().decode()
secret = getpass.getpass("API secret: ")
print("ENCRYPTION_KEY=" + key)
print("*_API_SECRET=" + Fernet(key.encode()).encrypt(secret.encode()).decode())
