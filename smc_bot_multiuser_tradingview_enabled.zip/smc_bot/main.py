import asyncio, logging, os
from logging.handlers import RotatingFileHandler


async def main():
    os.makedirs("data/users", exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        handlers=[logging.StreamHandler(), RotatingFileHandler("data/bot.log", maxBytes=5_000_000, backupCount=5)])
    from aiogram import Bot, Dispatcher
    from config import Settings
    from tenant import TenantManager
    from telegram_bot.bot import build_router
    s=Settings()
    if not s.admins: raise SystemExit("ADMIN_IDS порожній — вкажіть Telegram ID власника у .env")
    if not s.encryption_key: raise SystemExit("ENCRYPTION_KEY обов’язковий. Згенеруйте його: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\"")
    manager=TenantManager(s)
    tv_runner = None
    if s.tv_enable:
        from tradingview.webhook import start as start_tv
        tv_runner = await start_tv(manager, s.tv_port, {x.strip() for x in s.tv_allowed_ips.split(',') if x.strip()})
    bot=Bot(s.telegram_bot_token)
    dp=Dispatcher(); dp.include_router(build_router(manager))
    try:
        await dp.start_polling(bot)
    finally:
        if tv_runner: await tv_runner.cleanup()
        await manager.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
