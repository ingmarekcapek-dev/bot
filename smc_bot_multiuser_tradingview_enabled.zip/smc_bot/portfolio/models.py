from __future__ import annotations
import json, os
from dataclasses import dataclass, field, asdict, fields


@dataclass
class Position:
    id: str
    symbol: str
    side: str                 # long | short
    entry: float
    qty: float                # у контрактах біржі
    initial_qty: float
    sl: float
    legs: list                # [[tp_price, qty], ...]
    mode: str
    opened_at: int
    risk_usdt: float
    cs: float = 1.0           # contract size
    signal_key: str = ""
    entry_sl: float = 0.0
    legs_done: int = 0
    sl_order_id: str = ""
    sl_order_ids: list = field(default_factory=list)
    tp_order_ids: list = field(default_factory=list)
    close_order_ids: list = field(default_factory=list)
    realized: float = 0.0
    fees: float = 0.0
    last_check_ts: int = 0

    @property
    def d(self) -> int:
        return 1 if self.side == "long" else -1


@dataclass
class BotState:
    running: bool = False
    auto_trade: bool = False
    mode: str = "paper"                    # paper | demo | live
    kill_switch: bool = False
    risk_pct: float = 0.5
    max_risk_pct: float = 1.0
    leverage: int = 5
    symbols: list = field(default_factory=lambda: ["BTC/USDT:USDT", "ETH/USDT:USDT"])
    trigger_tf: str = "15m"
    confirm_tf: str = "5m"
    max_positions: int = 3
    daily_dd_pct: float = 2.0
    weekly_dd_pct: float = 5.0
    min_rr: float = 2.0
    max_consec_losses: int = 3
    consecutive_losses: int = 0
    # фільтри
    max_spread_pct: float = 0.05
    max_funding_pct: float = 0.10
    max_atr_pct: float = 3.0
    min_quote_volume: float = 20_000_000
    max_same_direction: int = 2
    # облік
    paper_balance: float = 1000.0
    day_key: str = ""
    day_start_equity: float = 0.0
    week_key: str = ""
    week_start_equity: float = 0.0
    last_halt_msg: str = ""
    positions: list = field(default_factory=list)   # list[Position]

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        data = asdict(self)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)

    @classmethod
    def load(cls, path: str) -> "BotState":
        st = cls()
        if not os.path.exists(path):
            return st
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        known = {f.name for f in fields(cls)}
        for k, v in raw.items():
            if k in known and k != "positions":
                setattr(st, k, v)
        pk = {f.name for f in fields(Position)}
        st.positions = [Position(**{k: v for k, v in p.items() if k in pk}) for p in raw.get("positions", [])]
        # безпечний старт: після рестарту торгівля не вмикається сама
        st.running = False
        st.auto_trade = False
        return st
