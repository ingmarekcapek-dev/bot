"""Виконання: PAPER (симуляція на реальних цінах) та DEMO/LIVE (ордери на біржі).
SL/TP живуть на біржі (reduceOnly); бот лише звіряє їх і переносить SL."""
from __future__ import annotations
import logging, time, uuid
from portfolio.models import Position

log = logging.getLogger("executor")
SPLIT = (0.5, 0.3, 0.2)
FEE = 0.0005; SLIP = 0.0002; TRAIL_ATR = 1.5


def _ev(type_, pos, text, pnl=None): return {"type": type_, "pos": pos, "text": text, "pnl": pnl}


class Executor:
    def __init__(self, state, public, trade=None):
        self.st, self.pub, self.tr = state, public, trade
        self.paper = trade is None
        self.last_px: dict[str, float] = {}
        self.blocked_symbols: set[str] = set()

    # ---------- рахунок ----------
    async def equity(self) -> float:
        if self.paper:
            unreal = sum((self.last_px.get(p.symbol, p.entry) - p.entry) * p.d * p.qty * p.cs for p in self.st.positions)
            return self.st.paper_balance + unreal
        bal = await self.tr.ex.fetch_balance()
        return float((bal.get("total") or {}).get("USDT") or 0)

    # ---------- допоміжне ----------
    def _split(self, sym, qty, tps):
        mn = (self.pub.market(sym)["limits"]["amount"] or {}).get("min") or 0
        legs, carry = [], 0.0; rest = qty
        for i, (tp, f) in enumerate(zip(tps, SPLIT)):
            q = rest if i == 2 else self.pub.round_amount(sym, qty * f)
            rest -= q; q += carry; carry = 0.0
            if q < mn: carry = q; continue
            legs.append([tp, q])
        if carry and legs: legs[-1][1] += carry
        if not legs: legs = [[tps[1], qty]]
        # +1e-9: похибка float не має «з'їдати» крок біржі в залишку останньої частини
        return [[self.pub.round_price(sym, t), self.pub.round_amount(sym, q + 1e-9)] for t, q in legs]

    async def _orders(self, sym):
        ex = self.tr.ex; res = {}; successes = 0; errors = []
        for params in ({}, {"trigger": True}):
            try:
                orders = await ex.fetch_open_orders(sym, params=params)
                successes += 1
                for o in orders: res[o["id"]] = o
            except Exception as e:
                errors.append(e)
                log.warning("fetch_open_orders %s params=%s: %s", sym, params, e)
        # An API failure is not evidence that protective orders are absent.
        if errors or successes < 2:
            raise RuntimeError(f"Неповна перевірка відкритих ордерів {sym}; не можна підтвердити стан SL/TP: {errors}")
        return list(res.values())

    @staticmethod
    def _is_stop(o): return bool(o.get("stopPrice") or o.get("triggerPrice")) and bool(o.get("reduceOnly", True))

    async def _place_sl(self, pos: Position, price: float, qty: float):
        close = "sell" if pos.d == 1 else "buy"
        o = await self.tr.ex.create_order(pos.symbol, "market", close, qty, None,
                                          {"stopLossPrice": self.pub.round_price(pos.symbol, price), "reduceOnly": True})
        oid = str(o["id"])
        if oid not in pos.sl_order_ids: pos.sl_order_ids.append(oid)
        return oid

    # ---------- відкриття ----------
    async def open(self, sig, size: dict, leverage: int) -> Position:
        sym = sig.symbol; d = 1 if sig.direction == "LONG" else -1; qty = size["qty"]
        legs = self._split(sym, qty, [sig.tp1, sig.tp2, sig.tp3])
        pos = Position(id=uuid.uuid4().hex[:10], symbol=sym, side="long" if d == 1 else "short", entry=sig.entry,
                       qty=qty, initial_qty=qty, sl=self.pub.round_price(sym, sig.sl), legs=legs,
                       mode=self.st.mode, opened_at=int(time.time() * 1000), risk_usdt=size["risk_usdt"],
                       cs=size["cs"], signal_key=sig.key, entry_sl=sig.sl)
        pos.last_check_ts = pos.opened_at
        if self.paper:
            pos.entry = sig.entry * (1 + SLIP * d)
            fee = pos.entry * qty * pos.cs * FEE
            pos.fees += fee; self.st.paper_balance -= fee
            return pos
        ex = self.tr.ex; side = "buy" if d == 1 else "sell"; close = "sell" if d == 1 else "buy"
        # The bot uses one-way symbol positions. Never merge into a manual or orphaned position.
        existing = await ex.fetch_positions([sym])
        existing_qty = sum(abs(float(x.get("contracts") or 0)) for x in existing if x.get("symbol") == sym)
        if existing_qty > 1e-12:
            self.blocked_symbols.add(sym)
            raise RuntimeError(f"На біржі вже є позиція {sym} ({existing_qty}); бот не відкриватиме угоду поверх чужої позиції")
        try:
            await ex.set_margin_mode("isolated", sym)
        except Exception as e:
            msg = str(e).lower()
            if not any(x in msg for x in ("already isolated", "no need to change margin type", "-4046", "110026")):
                raise RuntimeError(f"Не вдалося підтвердити isolated margin для {sym}: {e}") from e
        try:
            await ex.set_leverage(leverage, sym)
        except Exception as e:
            msg = str(e).lower()
            if not any(x in msg for x in ("already set", "no need to change leverage")):
                raise RuntimeError(f"Не вдалося встановити плече {leverage}x для {sym}: {e}") from e
        cid = "smc" + pos.id
        o = await ex.create_order(sym, "market", side, qty, None, {"clientOrderId": cid})
        entry_fee = float((o.get("fee") or {}).get("cost") or 0)
        for _ in range(5):
            if float(o.get("filled") or 0) > 0 and float(o.get("average") or o.get("price") or 0) > 0:
                break
            if not o.get("id"):
                break
            o = await ex.fetch_order(o["id"], sym)
        requested_qty = qty
        filled = float(o.get("filled") or 0)
        average = float(o.get("average") or o.get("price") or 0)
        if filled <= 0:
            # Some venues omit `filled` on the immediate response. Query the live position
            # before deciding the order failed; reduceOnly emergency close is safe on partials.
            try:
                live_positions = await ex.fetch_positions([sym])
                filled = sum(abs(float(x.get("contracts") or 0)) for x in live_positions if x.get("symbol") == sym)
            except Exception as fetch_error:
                try: await ex.create_order(sym, "market", close, qty, None, {"reduceOnly": True})
                except Exception as close_error:
                    raise RuntimeError(f"Не вдалося підтвердити fill або аварійно закрити можливу позицію: {fetch_error}; {close_error}")
                raise RuntimeError(f"Не вдалося підтвердити виконання market-ордера; надіслано аварійне reduceOnly-закриття: {fetch_error}")
        if filled <= 0:
            raise RuntimeError("Біржа не підтвердила відкриття позиції (filled=0)")
        if average <= 0:
            average = float(sig.entry)  # only used as a conservative reference if venue omits average
            log.warning("Average fill missing for %s; using signal entry as accounting reference", sym)
        # Partial fills are valid, but all protection must use the actually filled size.
        pos.qty = pos.initial_qty = filled
        pos.risk_usdt *= min(1.0, filled / requested_qty) if requested_qty > 0 else 1.0
        pos.entry = average
        pos.legs = self._split(sym, filled, [sig.tp1, sig.tp2, sig.tp3])
        pos.fees += entry_fee or float((o.get("fee") or {}).get("cost") or 0)
        try:
            pos.sl_order_id = await self._place_sl(pos, pos.sl, pos.qty)
            for tp, q in pos.legs:
                t = await ex.create_order(sym, "limit", close, q, tp, {"reduceOnly": True})
                pos.tp_order_ids.append(t["id"])
            # If the exchange API cannot confirm both regular and trigger orders,
            # do not register an unverified position as safely protected.
            if not any(self._is_stop(x) for x in await self._orders(sym)):
                raise RuntimeError("SL не підтверджено на біржі після виставлення")
        except Exception as e:
            log.error("захисні ордери не підтверджено: %s -> аварійне закриття", e)
            try:
                await self.close_position(pos, "не вдалося підтвердити SL/TP")
            except Exception as close_error:
                raise RuntimeError(f"КРИТИЧНО: SL/TP не підтверджено; аварійне закриття також не вдалося: {close_error}. Перевірте позицію {sym} на біржі вручну") from e
            raise RuntimeError(f"SL/TP не підтверджено, виконано аварійне закриття: {e}") from e
        return pos

    # ---------- закриття ----------
    async def close_position(self, pos: Position, reason: str, price: float | None = None):
        if self.paper:
            px = price or self.last_px.get(pos.symbol, pos.entry)
            return self._paper_fill(pos, pos.qty, px, reason)
        ex = self.tr.ex
        # Read actual exchange size; local state can be stale after partial fills/restarts.
        positions = await ex.fetch_positions([pos.symbol])
        actual = sum(abs(float(x.get("contracts") or 0)) for x in positions if x.get("symbol") == pos.symbol)
        if actual <= 1e-12:
            return
        close_qty = min(actual, max(0.0, pos.qty))
        if close_qty <= 1e-12:
            raise RuntimeError(f"Локальна кількість {pos.symbol} дорівнює нулю, відмовлено від закриття невідомого обсягу")
        for params in ({}, {"trigger": True}):
            try: await ex.cancel_all_orders(pos.symbol, params=params)
            except Exception as e: log.warning("cancel orders %s params=%s: %s", pos.symbol, params, e)
        close = "sell" if pos.d == 1 else "buy"
        result = await ex.create_order(pos.symbol, "market", close, close_qty, None, {"reduceOnly": True})
        if result.get("id"):
            pos.close_order_ids.append(str(result["id"]))

    def _paper_fill(self, pos, qty, px, reason, slip=True):
        fill = px * (1 - SLIP * pos.d) if slip else px
        pnl = (fill - pos.entry) * pos.d * qty * pos.cs; fee = fill * qty * pos.cs * FEE
        pos.qty -= qty; pos.realized += pnl; pos.fees += fee
        self.st.paper_balance += pnl - fee
        return pnl - fee

    # ---------- супровід ----------
    async def manage(self, ctx: dict) -> list[dict]:
        evs = []
        for pos in list(self.st.positions):
            c = ctx.get(pos.symbol)
            if c: self.last_px[pos.symbol] = c["price"]
            try:
                evs += await (self._manage_paper(pos, c) if self.paper else self._manage_live(pos, c))
            except Exception as e:
                log.exception("manage %s", pos.symbol); evs.append(_ev("info", pos, f"⚠️ Помилка супроводу {pos.symbol}: {e}"))
        return evs

    def _finish(self, pos, reason):
        net = pos.realized - pos.fees
        return _ev("closed", pos, reason, net)

    async def _manage_paper(self, pos, c):
        evs = []
        if not c: return evs
        df = c["m5"]; rows = df[df["ts"] > pos.last_check_ts]
        for r in rows.itertuples():
            pos.last_check_ts = int(r.ts); d = pos.d
            if (r.low <= pos.sl) if d == 1 else (r.high >= pos.sl):
                self._paper_fill(pos, pos.qty, pos.sl, "SL")
                evs.append(self._finish(pos, "SL" if pos.legs_done == 0 else "SL (беззбиток/трейлінг)")); return evs
            while pos.legs_done < len(pos.legs):
                tp, q = pos.legs[pos.legs_done]
                if not ((r.high >= tp) if d == 1 else (r.low <= tp)): break
                self._paper_fill(pos, min(q, pos.qty), tp, "TP", slip=False); pos.legs_done += 1
                evs.append(_ev("tp", pos, f"🎯 TP{pos.legs_done} досягнуто ({tp})"))
                if pos.legs_done == 1: pos.sl = pos.entry
                if pos.qty <= 1e-12 or pos.legs_done == len(pos.legs):
                    if pos.qty > 1e-12: self._paper_fill(pos, pos.qty, tp, "TP", slip=False)   # залишок через округлення
                    evs.append(self._finish(pos, "Всі TP виконано")); return evs
            if pos.legs_done >= 1 and c.get("atr"):
                new = r.close - d * TRAIL_ATR * c["atr"]
                if (new - pos.sl) * d > 0: pos.sl = new
        return evs

    async def _manage_live(self, pos, c):
        evs = []; ex = self.tr.ex
        ps = await ex.fetch_positions([pos.symbol])
        cur = sum(abs(float(p.get("contracts") or 0)) for p in ps)
        if cur <= 1e-12:
            for params in ({}, {"trigger": True}):
                try: await ex.cancel_all_orders(pos.symbol, params=params)
                except Exception as e: log.warning("cleanup orders %s params=%s: %s", pos.symbol, params, e)
            pnl = await self._live_pnl(pos)
            pos.realized = pnl[0]
            pos.fees += pnl[1]  # retain the entry fee already recorded at order placement
            return [self._finish(pos, "Позицію закрито на біржі (SL/TP/ручне)")]
        if cur > pos.qty * 1.01 + 1e-9:
            self.blocked_symbols.add(pos.symbol)
            raise RuntimeError(f"На біржі кількість {pos.symbol} ({cur}) більша за облік бота ({pos.qty}); можлива ручна угода. Автоматичне керування зупинено")
        pos.qty = cur
        filled = pos.initial_qty - cur; cum = 0.0; done = 0
        for _, q in pos.legs:
            cum += q
            if filled >= cum * 0.99: done += 1
        if done > pos.legs_done:
            pos.legs_done = done; evs.append(_ev("tp", pos, f"🎯 TP{done} виконано на біржі"))
            if done == 1: await self._move_sl(pos, pos.entry)
        orders = await self._orders(pos.symbol)
        if not any(self._is_stop(o) for o in orders):
            evs.append(_ev("info", pos, f"🚨 Відсутній SL на біржі для {pos.symbol}! Виставляю повторно."))
            pos.sl_order_id = await self._place_sl(pos, pos.sl, cur)
        elif done >= 1 and c and c.get("atr"):
            new = c["price"] - pos.d * TRAIL_ATR * c["atr"]
            if (new - pos.sl) * pos.d > c["atr"] * 0.2: await self._move_sl(pos, new)
        return evs

    async def _move_sl(self, pos, price):
        new_id = await self._place_sl(pos, price, pos.qty)      # спочатку новий, потім старий (без «дірки»)
        if pos.sl_order_id:
            cancelled = False
            for params in ({}, {"trigger": True}):
                try:
                    await self.tr.ex.cancel_order(pos.sl_order_id, pos.symbol, params=params)
                    cancelled = True; break
                except Exception as e:
                    log.debug("cancel old SL params=%s: %s", params, e)
            if not cancelled: log.error("Не вдалося скасувати старий SL %s для %s", pos.sl_order_id, pos.symbol)
        pos.sl_order_id, pos.sl = new_id, self.pub.round_price(pos.symbol, price)

    async def _live_pnl(self, pos):
        try:
            tr = await self.tr.ex.fetch_my_trades(pos.symbol, since=pos.opened_at - 5000)
            close = "sell" if pos.d == 1 else "buy"
            known_ids = {str(x) for x in (pos.tp_order_ids + pos.close_order_ids + pos.sl_order_ids + [pos.sl_order_id]) if x}
            gross = fees = 0.0; closed_qty = 0.0
            for t in tr:
                # Never attribute unrelated manual/other-bot trades on this symbol to this position.
                if str(t.get("order") or t.get("orderId") or "") not in known_ids:
                    continue
                if t.get("side") != close:
                    continue
                amount = min(float(t.get("amount") or 0), max(0.0, pos.initial_qty - closed_qty))
                if amount <= 0: continue
                gross += (float(t["price"]) - pos.entry) * pos.d * amount * pos.cs
                fees += float((t.get("fee") or {}).get("cost") or 0)
                closed_qty += amount
            if closed_qty + 1e-9 < pos.initial_qty:
                log.warning("PnL incomplete for %s: matched %.8f/%.8f contracts", pos.symbol, closed_qty, pos.initial_qty)
            return gross, fees
        except Exception as e:
            log.warning("pnl fetch: %s", e); return 0.0, 0.0

    # ---------- відновлення після рестарту ----------
    async def reconcile(self) -> list[str]:
        msgs = []
        if self.paper: return [f"PAPER: відновлено {len(self.st.positions)} позицій зі state"]
        ex = self.tr.ex
        ps = await ex.fetch_positions(self.st.symbols)
        live = {p["symbol"]: abs(float(p.get("contracts") or 0)) for p in ps if abs(float(p.get("contracts") or 0)) > 0}
        for pos in list(self.st.positions):
            if pos.symbol not in live:
                # Keep the persisted record. The normal manager will reconcile it as closed
                # and calculate PnL; silently dropping it loses trade history and fees.
                msgs.append(f"⚠️ {pos.symbol}: позиції на біржі не знайдено; запис збережено до перевірки PnL")
            else:
                if live[pos.symbol] > pos.qty * 1.01 + 1e-9:
                    self.blocked_symbols.add(pos.symbol)
                    msgs.append(f"🚨 {pos.symbol}: кількість на біржі більша за state; автоматичне керування заблоковано до ручної перевірки")
                    continue
                pos.qty = live[pos.symbol]
                filled_qty = max(0.0, pos.initial_qty - pos.qty)
                cumulative = 0.0; completed = 0
                for _, leg_qty in pos.legs:
                    cumulative += leg_qty
                    if filled_qty >= cumulative * 0.99: completed += 1
                pos.legs_done = max(pos.legs_done, completed)
                orders = await self._orders(pos.symbol)
                if not any(self._is_stop(o) for o in orders):
                    pos.sl_order_id = await self._place_sl(pos, pos.sl, live[pos.symbol])
                    msgs.append(f"🛡 {pos.symbol}: SL відновлено")
        known = {p.symbol for p in self.st.positions}
        for s in live:
            if s not in known:
                self.blocked_symbols.add(s)
                msgs.append(f"⚠️ На біржі є невідома боту позиція {s} — бот її не чіпає та не відкриватиме нові угоди по цій парі")
        return msgs or ["Стан синхронізовано з біржею"]

    async def emergency_close_all(self):
        for pos in list(self.st.positions):
            try: await self.close_position(pos, "emergency")
            except Exception as e: log.error("emergency close %s: %s", pos.symbol, e)
