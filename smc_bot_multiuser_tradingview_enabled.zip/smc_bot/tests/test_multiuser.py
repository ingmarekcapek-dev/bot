import sqlite3
from cryptography.fernet import Fernet
from tenant import AccountStore


def test_account_keys_are_encrypted_and_isolated(tmp_path):
    key=Fernet.generate_key().decode()
    store=AccountStore(key, str(tmp_path/'accounts.sqlite3'))
    store.allow(101); store.allow(202)
    store.save_keys(101,'live','alice-key','alice-secret')
    store.save_keys(202,'live','bob-key','bob-secret')
    assert store.keys(101,'live') == ('alice-key','alice-secret')
    assert store.keys(202,'live') == ('bob-key','bob-secret')
    raw=(tmp_path/'accounts.sqlite3').read_bytes()
    assert b'alice-secret' not in raw and b'bob-secret' not in raw
    assert store.allowed(101) and store.allowed(202)
    store.revoke(101)
    assert not store.allowed(101) and store.keys(101,'live') == ('','')
    assert store.keys(202,'live') == ('bob-key','bob-secret')
    store.db.close()


def test_tradingview_tokens_are_encrypted_and_isolated(tmp_path):
    key = Fernet.generate_key().decode()
    store = AccountStore(key, str(tmp_path / 'accounts.sqlite3'))
    store.allow(101); store.allow(202)
    alice = store.create_tv_token(101)
    bob = store.create_tv_token(202)
    assert alice != bob
    assert store.tv_owner(alice) == (101, True)
    assert store.tv_owner(bob) == (202, True)
    assert store.tv_owner('not-a-token') == (None, False)
    assert store.tv_status(101) == (alice, True)
    assert store.claim_tv_event(101, 'alert-1', 1000) is True
    assert store.claim_tv_event(101, 'alert-1', 1001) is False
    assert store.claim_tv_event(202, 'alert-1', 1001) is True
    store.set_tv_enabled(101, False)
    assert store.tv_owner(alice) == (101, False)
    assert store.tv_owner(bob) == (202, True)
    raw = (tmp_path / 'accounts.sqlite3').read_bytes()
    assert alice.encode() not in raw and bob.encode() not in raw
    store.revoke(101)
    assert store.tv_owner(alice) == (None, False)
    assert store.tv_owner(bob) == (202, True)
    store.db.close()
