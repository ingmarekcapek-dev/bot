import numpy as np, pandas as pd, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from smart_money.structure import find_swings, trend, atr, find_fvgs
from order_blocks.detector import detect_order_blocks
from risk_management.manager import RiskManager
from backtesting.engine import run, resample


def synth(n=12000, seed=1):
    rng = np.random.default_rng(seed)
    r = rng.normal(0, 0.0015, n) + np.sin(np.arange(n) / 400) * 0.0004
    c = 100 * np.exp(np.cumsum(r)); o = np.r_[c[0], c[:-1]]
    h = np.maximum(o, c) * (1 + rng.random(n) * 0.001); l = np.minimum(o, c) * (1 - rng.random(n) * 0.001)
    ts = 1_700_000_000_000 + np.arange(n) * 300_000
    return pd.DataFrame({"ts": ts, "open": o, "high": h, "low": l, "close": c, "volume": rng.random(n) * 100 + 50})


def test_swings_no_lookahead():
    df = synth(500)
    full = find_swings(df, 3); part = find_swings(df.iloc[:300], 3)
    # свінги, підтверджені до 299 на повних даних, збігаються з обчисленими лише на 300 свічках
    a = [(s.idx, s.kind) for s in full if s.confirmed <= 296]
    b = [(s.idx, s.kind) for s in part if s.confirmed <= 296]
    assert a == b


def test_position_size():
    rm = RiskManager(); mkt = {"contractSize": 1, "limits": {"amount": {"min": 0.001}, "cost": {"min": 5}}}
    res, why = rm.size(1000, 100, 98, 0.5, 1.0, 5, mkt, lambda q: int(q * 1000) / 1000)
    assert res and abs(res["risk_usdt"] - 5) < 0.05, (res, why)
    res, why = rm.size(1000, 100, 98, 5.0, 1.0, 5, mkt, lambda q: int(q * 1000) / 1000)   # ризик обрізається до 1%
    assert res["risk_usdt"] <= 10.05


def test_limits():
    from portfolio.models import BotState
    st = BotState(); st.day_start_equity = 1000; st.week_start_equity = 1000
    assert not RiskManager().allowed(st, 979, 0)[0]
    st.consecutive_losses = 3
    assert not RiskManager().allowed(st, 1000, 0)[0]


def test_resample_and_backtest_runs():
    df = synth(12000)
    assert len(resample(df, "1h")) > 900
    m, trades = run(df, warmup_days=45)
    assert isinstance(m, dict)


if __name__ == "__main__":
    for _n, _f in list(globals().items()):
        if _n.startswith("test_"): _f(); print("OK  ", _n)


def test_backtest_rejects_1m_confirmation_without_1m_source():
    import pytest
    from strategies.smc_breakout import Params
    with pytest.raises(ValueError, match="confirm_tf=1m"):
        run(synth(12000), p=Params(confirm_tf="1m"), warmup_days=45)
