"""Інтеграційні тести: engine + executor + risk на імітованій біржі (без мережі).
Запуск: python tests/test_integration.py   (або pytest)"""
import asyncio, os, sys, time, tempfile, types
from types import SimpleNamespace
from unittest.mock import MagicMock, AsyncMock
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT)
import numpy as np, pandas as pd

for mod in ("aiogram", "aiogram.enums", "ccxt", "ccxt.async_support"):
    try: __import__(mod)
    except Exception: sys.modules[mod] = MagicMock()
try: import config  # noqa
except Exception:
    m = types.ModuleType("config"); m.Settings = object; sys.modules["config"] = m
try: import database.db  # noqa
except Exception:
    m = types.ModuleType("database.db"); m.Database = object; sys.modules["database.db"] = m

import engine as E
from engine import App
from execution.executor import Executor
from market_data.timeframes import TF_MS
from order_blocks.detector import OrderBlock
from portfolio.models import BotState, Position
from strategies.smc_breakout import Signal

SYM = "BTC/USDT:USDT"


class FakeDB:
    def __init__(self): self.sigs = set(); self.trades_saved = []; self.logs = []
    async def log(self, *a, **k): self.logs.append(a)
    async def signal_exists(self, key): return key in self.sigs
    async def save_signal(self, sig, executed): self.sigs.add(sig.key)
    async def save_trade(self, pos, pnl, reason): self.trades_saved.append((pos.id, pnl, reason))
    async def trades(self, *a, **k): return []


class FakePub:
    """Імітація публічного Exchange: свічки, спред, funding, округлення."""
    def __init__(self): self.extra5 = []; self.now = int(time.time() * 1000)
    def market(self, s): return {"contractSize": 1, "limits": {"amount": {"min": 0.001}, "cost": {"min": 5}}}
    def round_amount(self, s, q): return int(q * 1000) / 1000
    def round_price(self, s, p): return round(p, 2)
    async def snapshot(self, s): return {"spread_pct": 0.01, "funding": 0.0001, "mark": 100.0, "index": 100.0, "oi": 1, "quote_volume": 1e9}
    async def ohlcv(self, s, tf, limit):
        ms = TF_MS[tf]; n = 120
        if tf == "5m":
            last = self.now // ms * ms + ms
            ts = last - np.arange(n)[::-1] * ms
            ts = np.r_[ts, [last + ms * (k + 1) for k in range(len(self.extra5))]]
            o = np.full(len(ts), 100.0); h = o + 0.1; l = o - 0.1; c = o.copy(); n2 = len(ts)
            for k, (hi, lo) in enumerate(self.extra5):
                i = n + k; h[i] = hi; l[i] = lo; c[i] = (hi + lo) / 2; o[i] = c[i]
        else:
            last = self.now // ms * ms - ms
            ts = last - np.arange(n)[::-1] * ms
            o = np.full(n, 100.0); h = o + 0.1; l = o - 0.1; c = o.copy()
        return pd.DataFrame({"ts": ts.astype("int64"), "open": o, "high": h, "low": l, "close": c, "volume": 100.0})


def make_signal(direction="LONG", key="k1"):
    long = direction == "LONG"; d = 1 if long else -1
    ob = OrderBlock("bearish" if long else "bullish", 99.5, 100.0, 1, 2, 123)
    return Signal(SYM, direction, 100.0, 100 - d * 1.0, 100 + d * 2.1, 100 + d * 3.2, 100 + d * 4.3, 2.0, "15m",
                  ob, "BOS", (99.0, 99.4), 75, ["тест"], key, 0.2)


def make_app(tmp, sig_dir="LONG", key="k1"):
    s = SimpleNamespace(telegram_bot_token="1:x", admins={1}, exchange="binance", state_file=os.path.join(tmp, "st.json"),
                        database_url="x", loop_interval_sec=1)
    app = App.__new__(App)
    app.s = s; app.state = BotState(); app.state.symbols = [SYM]; app.state.running = True; app.state.auto_trade = True
    app.public = FakePub(); from market_data.feed import MarketFeed; app.feed = MarketFeed(app.public)
    from risk_management.manager import RiskManager
    app.risk = RiskManager(); app.db = FakeDB(); app.bot = SimpleNamespace(send_message=AsyncMock())
    app.tr = None; app.executor = Executor(app.state, app.public, None)
    app.tv_hints = {}; app.api_errors = 0; app.tick_errors = 0; app._lock = asyncio.Lock()
    fired = {"n": 0}
    def fake_analyze(sym, fr, p, tv=None):
        return (make_signal(sig_dir, key), []) if True else (None, [])
    E.analyze = fake_analyze
    return app


async def tick(app, extra=None):
    app.feed.cache.clear()
    if extra is not None: app.public.extra5 = extra
    await app.tick()


def msgs(app): return [c.args[1] for c in app.bot.send_message.call_args_list]


def test_paper_long_all_tps():
    async def go():
        with tempfile.TemporaryDirectory() as tmp:
            app = make_app(tmp); await tick(app)
            assert len(app.state.positions) == 1, msgs(app)
            pos = app.state.positions[0]; assert abs(pos.risk_usdt - 5) < 0.3, pos.risk_usdt
            assert pos.sl < pos.entry and len(pos.legs) == 3 and abs(sum(q for _, q in pos.legs) - pos.qty) < 1e-9
            bal0 = app.state.paper_balance
            t1, t2, t3 = (x[0] for x in pos.legs)
            await tick(app, [(t1 + .01, 100.5), (t2 + .01, 101.0), (t3 + .01, 102.0)])
            assert not app.state.positions, "позиція має закритись після TP3"
            assert app.state.paper_balance > bal0 and app.db.trades_saved[0][1] > 0
            assert app.state.consecutive_losses == 0
            # повторний сигнал з тим самим key не відкриває нову угоду (anti-replay)
            await tick(app, []); assert not app.state.positions
    asyncio.run(go())


def test_paper_short_stop_loss_counts_loss():
    async def go():
        with tempfile.TemporaryDirectory() as tmp:
            app = make_app(tmp, "SHORT", "k2"); await tick(app)
            pos = app.state.positions[0]; assert pos.side == "short" and pos.sl > pos.entry
            await tick(app, [(pos.sl + 0.5, 99.9)])
            assert not app.state.positions
            pnl = app.db.trades_saved[0][1]
            assert -6.5 < pnl < -4.9, pnl           # ≈ -ризик (5) з комісіями/slippage
            assert app.state.consecutive_losses == 1
    asyncio.run(go())


def test_paper_tp1_then_breakeven_not_a_loss():
    async def go():
        with tempfile.TemporaryDirectory() as tmp:
            app = make_app(tmp, "LONG", "k3"); await tick(app)
            pos = app.state.positions[0]; t1 = pos.legs[0][0]
            await tick(app, [(t1 + .01, 100.5), (101.0, 99.0)])
            assert not app.state.positions and app.db.trades_saved[0][1] > 0
    asyncio.run(go())


def test_three_losses_halt_and_daily_limit():
    async def go():
        with tempfile.TemporaryDirectory() as tmp:
            app = make_app(tmp); app.state.consecutive_losses = 3; await tick(app)
            assert not app.state.positions and any("збитків поспіль" in m for m in msgs(app))
            app.state.consecutive_losses = 0; app.state.day_start_equity = 1000; app.state.paper_balance = 970
            app.state.day_key = time.strftime("%Y-%m-%d", time.gmtime()); app.state.last_halt_msg = ""
            await tick(app); assert not app.state.positions and any("просадка" in m for m in msgs(app))
            app.state.kill_switch = True; app.state.paper_balance = 1000; app.state.day_start_equity = 1000
            await tick(app); assert not app.state.positions
    asyncio.run(go())


def test_signal_only_when_auto_off_and_max_positions():
    async def go():
        with tempfile.TemporaryDirectory() as tmp:
            app = make_app(tmp); app.state.auto_trade = False; await tick(app)
            assert not app.state.positions and any("Лише сигнал" in m for m in msgs(app))
            app2 = make_app(tmp, key="k9"); app2.state.max_positions = 0; await tick(app2)
            assert not app2.state.positions and any("ліміт відкритих позицій" in m for m in msgs(app2))
    asyncio.run(go())


def test_state_persistence_safe_restart():
    with tempfile.TemporaryDirectory() as tmp:
        async def go():
            app = make_app(tmp); await tick(app); app.save()
            st = BotState.load(app.s.state_file)
            assert len(st.positions) == 1 and isinstance(st.positions[0], Position)
            assert st.running is False and st.auto_trade is False       # після рестарту торгівля сама не вмикається
        asyncio.run(go())


# ---------------- біржовий (LIVE/DEMO) шлях на імітованому ccxt ----------------
class FakeCcxt:
    def __init__(self, hide_stop=False, fail_sl=False):
        self.orders = []; self.log = []; self.contracts = 0.0; self.hide_stop = hide_stop; self.fail_sl = fail_sl; self.n = 0
        self.trades = []
    async def set_margin_mode(self, *a, **k): pass
    async def set_leverage(self, *a, **k): pass
    async def create_order(self, sym, typ, side, amt, price=None, params=None):
        params = params or {}; self.n += 1; oid = f"o{self.n}"
        self.log.append((typ, side, amt, price, dict(params)))
        if "stopLossPrice" in params:
            if self.fail_sl: raise RuntimeError("sl rejected")
            self.orders.append({"id": oid, "stopPrice": params["stopLossPrice"], "reduceOnly": True, "type": typ, "amount": amt})
        elif typ == "limit":
            self.orders.append({"id": oid, "price": price, "reduceOnly": params.get("reduceOnly", False), "type": typ, "amount": amt})
        elif typ == "market" and not params.get("reduceOnly"):
            self.contracts = amt
        return {"id": oid, "average": 100.0, "fee": {"cost": 0.02}}
    async def fetch_order(self, oid, sym): return {"id": oid, "average": 100.0}
    async def fetch_open_orders(self, sym, params=None):
        return [o for o in self.orders if not (self.hide_stop and o.get("stopPrice"))]
    async def cancel_order(self, oid, sym, params=None): self.orders = [o for o in self.orders if o["id"] != oid]
    async def cancel_all_orders(self, sym, params=None): self.orders = []
    async def fetch_positions(self, syms=None): return [{"symbol": SYM, "contracts": self.contracts}]
    async def fetch_my_trades(self, sym, since=None): return self.trades


def test_live_open_places_protection_and_manages():
    async def go():
        st = BotState(); st.mode = "live"; fx = FakeCcxt(); pub = FakePub()
        ex = Executor(st, pub, SimpleNamespace(ex=fx)); sig = make_signal()
        size = {"qty": 4.0, "risk_usdt": 5.0, "cs": 1.0}
        pos = await ex.open(sig, size, 3)
        stops = [o for o in fx.orders if o.get("stopPrice")]; tps = [o for o in fx.orders if o["type"] == "limit"]
        assert len(stops) == 1 and len(tps) == 3 and all(o["reduceOnly"] for o in tps)
        assert fx.log[0][4].get("clientOrderId", "").startswith("smc")           # idempotency id
        st.positions.append(pos)
        # TP1 виконано на біржі: позиція зменшилась -> SL у беззбиток, старий SL скасовано
        fx.contracts = pos.initial_qty - pos.legs[0][1]; fx.orders = [o for o in fx.orders if o["id"] != pos.tp_order_ids[0]]
        evs = await ex.manage({SYM: {"price": 101.0, "atr": 0.2, "m5": None}})
        assert any(e["type"] == "tp" for e in evs) and pos.legs_done == 1
        stops = [o for o in fx.orders if o.get("stopPrice")]
        assert len(stops) == 1 and stops[0]["stopPrice"] >= pos.entry - 0.01, stops      # рівно один SL, не нижче беззбитку
        # позицію закрито на біржі -> подія closed з PnL з угод
        fx.contracts = 0.0; fx.trades = [{"side": "sell", "price": 102.0, "amount": 2.0, "order": pos.tp_order_ids[1], "fee": {"cost": 0.1}},
                                          {"side": "sell", "price": 101.0, "amount": 2.0, "order": pos.tp_order_ids[2], "fee": {"cost": 0.1}}]
        evs = await ex.manage({SYM: None}); ev = [e for e in evs if e["type"] == "closed"][0]
        assert abs(ev["pnl"] - (2 * 2.0 + 1 * 2.0 - 0.2 - 0.02)) < 1e-6, ev["pnl"]
    asyncio.run(go())


def test_live_sl_rejected_closes_position_emergency():
    async def go():
        st = BotState(); st.mode = "live"; fx = FakeCcxt(fail_sl=True)
        ex = Executor(st, FakePub(), SimpleNamespace(ex=fx))
        try: await ex.open(make_signal(), {"qty": 4.0, "risk_usdt": 5.0, "cs": 1.0}, 3); assert False, "мав кинути виняток"
        except RuntimeError: pass
        assert fx.log[-1][0] == "market" and fx.log[-1][4].get("reduceOnly") is True    # аварійне закриття
    asyncio.run(go())


def test_live_sl_not_visible_after_placement_closes():
    async def go():
        st = BotState(); st.mode = "live"; fx = FakeCcxt(hide_stop=True)
        ex = Executor(st, FakePub(), SimpleNamespace(ex=fx))
        try: await ex.open(make_signal(), {"qty": 4.0, "risk_usdt": 5.0, "cs": 1.0}, 3); assert False
        except RuntimeError as e: assert "SL" in str(e)
        assert fx.log[-1][4].get("reduceOnly") is True
    asyncio.run(go())


def test_live_missing_sl_is_restored():
    async def go():
        st = BotState(); st.mode = "live"; fx = FakeCcxt(); ex = Executor(st, FakePub(), SimpleNamespace(ex=fx))
        pos = await ex.open(make_signal(), {"qty": 4.0, "risk_usdt": 5.0, "cs": 1.0}, 3); st.positions.append(pos)
        fx.orders = [o for o in fx.orders if not o.get("stopPrice")]          # SL «зник»
        evs = await ex.manage({SYM: None})
        assert any("Відсутній SL" in e["text"] for e in evs)
        assert len([o for o in fx.orders if o.get("stopPrice")]) == 1
    asyncio.run(go())


if __name__ == "__main__":
    import traceback
    ok = True
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            try: f(); print("OK  ", n)
            except Exception: ok = False; print("FAIL", n); traceback.print_exc()
    sys.exit(0 if ok else 1)


def test_live_partial_fill_protects_actual_quantity():
    async def go():
        st = BotState(); st.mode = "live"; fx = FakeCcxt(); pub = FakePub()
        original = fx.create_order
        async def partial(sym, typ, side, amt, price=None, params=None):
            result = await original(sym, typ, side, amt, price, params)
            if typ == "market" and not (params or {}).get("reduceOnly"):
                fx.contracts = amt / 2
                result["filled"] = amt / 2
            return result
        fx.create_order = partial
        ex = Executor(st, pub, SimpleNamespace(ex=fx))
        pos = await ex.open(make_signal("LONG", "partial"), {"qty": 4.0, "risk_usdt": 8.0, "cs": 1.0}, 3)
        assert pos.qty == pos.initial_qty == 2.0
        assert abs(pos.risk_usdt - 4.0) < 1e-9
        assert abs(sum(q for _, q in pos.legs) - 2.0) < 1e-9
        tp_orders = [o for o in fx.orders if o["type"] == "limit"]
        assert abs(sum(o["amount"] for o in tp_orders) - 2.0) < 1e-9
        sl = [o for o in fx.orders if o.get("stopPrice")]
        assert len(sl) == 1 and sl[0]["amount"] == 2.0
    asyncio.run(go())


def test_open_orders_api_failure_is_not_treated_as_missing_sl():
    async def go():
        st = BotState(); st.mode = "live"; fx = FakeCcxt()
        async def broken(*a, **k): raise RuntimeError("temporary exchange outage")
        fx.fetch_open_orders = broken
        ex = Executor(st, FakePub(), SimpleNamespace(ex=fx))
        try:
            await ex._orders(SYM)
            assert False, "must fail closed when order status cannot be checked"
        except RuntimeError as e:
            assert "Неповна перевірка" in str(e)
    asyncio.run(go())


def test_live_pnl_ignores_unrelated_same_symbol_trades():
    async def go():
        st = BotState(); st.mode = "live"; fx = FakeCcxt()
        ex = Executor(st, FakePub(), SimpleNamespace(ex=fx))
        pos = await ex.open(make_signal("LONG", "pnl-filter"), {"qty": 4.0, "risk_usdt": 5.0, "cs": 1.0}, 3)
        fx.trades = [
            {"side": "sell", "price": 200.0, "amount": 4.0, "order": "manual-unrelated", "fee": {"cost": 9.0}},
            {"side": "sell", "price": 102.0, "amount": 4.0, "order": pos.tp_order_ids[0], "fee": {"cost": 0.1}},
        ]
        gross, fees = await ex._live_pnl(pos)
        assert gross == 8.0 and abs(fees - 0.1) < 1e-9
    asyncio.run(go())


def test_live_refuses_to_merge_with_existing_manual_position():
    async def go():
        st = BotState(); st.mode = "live"; fx = FakeCcxt(); fx.contracts = 1.0
        ex = Executor(st, FakePub(), SimpleNamespace(ex=fx))
        try:
            await ex.open(make_signal("LONG", "manual-conflict"), {"qty": 4.0, "risk_usdt": 5.0, "cs": 1.0}, 5)
            assert False, "must refuse to merge with an existing position"
        except RuntimeError as e:
            assert "вже є позиція" in str(e)
        assert not fx.log
    asyncio.run(go())


def test_api_error_circuit_breaker_recovers_after_healthy_probe():
    async def go():
        with tempfile.TemporaryDirectory() as tmp:
            app = make_app(tmp, key="recover")
            app.api_errors = 3
            await tick(app)
            assert app.api_errors == 0
            assert len(app.state.positions) == 1
    asyncio.run(go())
