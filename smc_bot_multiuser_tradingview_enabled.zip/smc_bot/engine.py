from __future__ import annotations
import asyncio, html, logging, time
from aiogram import Bot
from aiogram.enums import ParseMode
from config import Settings
from database.db import Database
from exchanges.client import Exchange
from execution.executor import Executor
from market_data.feed import MarketFeed
from notifications import templates as T
from portfolio.models import BotState
from risk_management.manager import RiskManager
from smart_money.structure import atr
from strategies.smc_breakout import Params, analyze

log = logging.getLogger("engine")


class App:
    def __init__(self, s: Settings, user_id: int | None = None, user_keys: dict | None = None):
        self.user_id = user_id
        self.user_keys = user_keys or {}
        self._tenant_task = None
        self.s = s; self.state = BotState.load(s.state_file)
        self.public = Exchange(s.exchange); self.feed = MarketFeed(self.public)
        self.risk = RiskManager(); self.db = Database(s.database_url)
        self.bot = Bot(s.telegram_bot_token); self.tr = None; self.executor = None
        self.tv_hints: dict = {}; self.api_errors = 0; self.tick_errors = 0
        self.failed_signal_at: dict[str, float] = {}; self._lock = asyncio.Lock()

    def save(self): self.state.save(self.s.state_file)

    async def notify(self, text: str, markup=None):
        for uid in ([self.user_id] if getattr(self, "user_id", None) is not None else self.s.admins):
            try: await self.bot.send_message(uid, text, parse_mode=ParseMode.HTML, reply_markup=markup)
            except Exception as e: log.warning("notify %s: %s", uid, e)

    async def build_executor(self):
        if self.tr: await self.tr.close(); self.tr = None
        m = self.state.mode
        if m != "paper":
            if getattr(self, "user_id", None) is None:
                k, sec = self.s.keys(m)  # legacy single-account tests/compatibility
            else:
                k, sec = getattr(self, "user_keys", {}).get(m, ("", ""))  # never fall back to another user’s .env keys
            if not k or not sec: raise RuntimeError(f"Немає особистих API-ключів для режиму {m.upper()}. Натисніть «🔑 API-ключі» і додайте їх.")
            self.tr = Exchange(self.s.exchange, k, sec, demo=(m == "demo")); await self.tr.load()
        self.executor = Executor(self.state, self.public, self.tr)

    async def set_mode(self, mode: str):
        if self.state.positions: raise RuntimeError("Спочатку закрийте відкриті позиції")
        old = self.state.mode; self.state.mode = mode
        try: await self.build_executor()
        except Exception: self.state.mode = old; await self.build_executor(); raise
        self.state.auto_trade = False; self.state.day_key = self.state.week_key = ""; self.save()
        await self.db.log("telegram", "mode", mode)

    async def start(self):
        await self.db.init(); await self.public.load(); await self.build_executor()
        for m in await self.executor.reconcile(): await self.notify(m)
        self.save()

    def params(self) -> Params:
        st = self.state
        return Params(trigger_tf=st.trigger_tf, confirm_tf=st.confirm_tf, min_rr=st.min_rr)

    # ---------- головний цикл ----------
    async def loop(self):
        while True:
            try:
                async with self._lock: await self.tick()
            except Exception: log.exception("tick")
            await asyncio.sleep(self.s.loop_interval_sec)

    async def tick(self):
        st = self.state; p = self.params()
        try: eq = await self.executor.equity()
        except Exception as e:
            self.api_errors += 1; log.warning("equity: %s", e); return
        self.tick_errors = 0
        self.risk.roll(st, eq)
        # супровід відкритих позицій (завжди, навіть коли бот зупинений)
        ctx = {}
        for pos in st.positions:
            try:
                fr = await self.feed.frames(pos.symbol, [p.confirm_tf]); m5 = fr[p.confirm_tf]
                ctx[pos.symbol] = {"m5": m5, "price": float(m5["close"].iat[-1]), "atr": float(atr(m5).iat[-1])}
            except Exception as e: log.warning("ctx %s: %s", pos.symbol, e)
        for ev in await self.executor.manage(ctx): await self._event(ev)
        self.save()
        if self.api_errors >= 3 and st.running and st.symbols:
            try:
                probe = await self.feed.frames(st.symbols[0], ["1d", "4h", "1h", p.trigger_tf, p.confirm_tf])
                healthy, why = self.feed.validate_all(probe)
                if not healthy:
                    log.warning("API recovery probe failed: %s", why)
                    return
                self.api_errors = 0
            except Exception as e:
                log.warning("API recovery probe: %s", e)
                return
        if not st.running:
            self.api_errors = 0; return
        ok, why = self.risk.allowed(st, eq, self.api_errors)
        if not ok:
            if st.last_halt_msg != why:
                st.last_halt_msg = why; self.save(); await self.notify(f"⛔ <b>Нові угоди заблоковано:</b> {html.escape(why)}")
            return
        st.last_halt_msg = ""
        for sym in st.symbols:
            if any(x.symbol == sym for x in st.positions): continue
            try: await self._scan(sym, p, eq)
            except Exception as e:
                self.api_errors += 1; self.tick_errors += 1; log.warning("scan %s: %s", sym, e)
        # Reset only after equity, position management and every scan succeeded.
        if self.tick_errors == 0: self.api_errors = 0

    async def _event(self, ev):
        pos = ev["pos"]; st = self.state
        if ev["type"] in ("tp", "info"):
            await self.notify(f"<b>{pos.symbol}</b> {html.escape(ev['text'])}")
        elif ev["type"] == "closed":
            if pos in st.positions: st.positions.remove(pos)
            pnl = ev["pnl"]
            if pnl < -0.25 * pos.risk_usdt: st.consecutive_losses += 1
            elif pnl > 0.25 * pos.risk_usdt: st.consecutive_losses = 0
            await self.db.save_trade(pos, pnl, ev["text"]); self.save()
            await self.notify(T.closed_text(pos, pnl, html.escape(ev["text"])))
            if st.consecutive_losses >= st.max_consec_losses:
                await self.notify(f"🛑 {st.consecutive_losses} збитків поспіль — торгівлю зупинено. Перевірте систему та натисніть /resume.")

    async def _scan(self, sym, p, eq):
        st = self.state
        if sym in getattr(self.executor, "blocked_symbols", set()):
            log.warning("%s: торгівля заблокована через невідому/сторонню позицію", sym)
            return
        fr = await self.feed.frames(sym, ["1d", "4h", "1h", p.trigger_tf, p.confirm_tf])
        ok, why = self.feed.validate_all(fr)
        if not ok: log.info("%s: %s", sym, why); return
        hint = self.tv_hints.get(sym); tv = hint[0] if hint and time.time() - hint[1] < 1800 else None
        sig, notes = analyze(sym, fr, p, tv)
        if not sig:
            log.debug("%s: %s", sym, notes); return
        if await self.db.signal_exists(sig.key): return
        # Avoid repeated alerts while allowing a failed order to be retried later.
        failed_cache = getattr(self, "failed_signal_at", None)
        if failed_cache is None:
            failed_cache = self.failed_signal_at = {}
        failed_at = failed_cache.get(sig.key, 0.0)
        if time.time() - failed_at < 60:
            return
        # --- filters ---
        reason = await self._filters(sym, sig, fr[p.trigger_tf])
        can, why2 = self.risk.can_open(st, sig.direction)
        market = self.public.market(sym)
        size, why3 = self.risk.size(eq, sig.entry, sig.sl, st.risk_pct, st.max_risk_pct, st.leverage, market,
                                    lambda q: self.public.round_amount(sym, q), p.fee, p.slip)
        block = reason or (why2 if not can else "") or (why3 if not size else "")
        will_trade = st.auto_trade and not block
        await self.notify(T.signal_text(sig, size, st.leverage, will_trade) + (f"\n🚫 Блок: {html.escape(block)}" if block else ""))
        if will_trade:
            try:
                pos = await self.executor.open(sig, size, st.leverage)
                st.positions.append(pos); self.save()
                await self.db.save_signal(sig, True)
                await self.db.log("engine", "open", f"{pos.symbol} {pos.side} {pos.entry}")
                await self.notify(T.opened_text(pos))
                failed_cache.pop(sig.key, None)
            except Exception as e:
                # Do not mark a rejected order as executed: it may be retried after cooldown.
                failed_cache[sig.key] = time.time()
                log.exception("open"); await self.notify(f"❌ Не вдалося відкрити {sym}: {html.escape(str(e))}")
        else:
            await self.db.save_signal(sig, False)

    async def _filters(self, sym, sig, m15) -> str:
        st = self.state; snap = await self.public.snapshot(sym)
        if snap["spread_pct"] is None: return "не вдалося перевірити спред — угоду заблоковано"
        if snap["funding"] is None: return "не вдалося отримати funding — угоду заблоковано"
        if snap["quote_volume"] is None: return "не вдалося перевірити 24h обсяг — угоду заблоковано"
        if snap["spread_pct"] > st.max_spread_pct: return f"великий спред {snap['spread_pct']:.3f}%"
        f = snap["funding"] * 100
        if abs(f) > st.max_funding_pct: return f"надмірний funding {f:.3f}%"
        if snap["quote_volume"] < st.min_quote_volume: return "низька ліквідність (24h обсяг)"
        a = float(atr(m15).iat[-1]) / sig.entry * 100
        if a > st.max_atr_pct: return f"надмірна волатильність ATR {a:.2f}%"
        if snap["mark"] and abs(snap["mark"] - sig.entry) / sig.entry > 0.005: return "ціна входу розходиться з mark price"
        return ""
