from __future__ import annotations
import datetime as dt
import math


class RiskManager:
    # ---------- періоди ----------
    def roll(self, st, equity: float) -> None:
        now = dt.datetime.now(dt.timezone.utc)
        dk = now.strftime("%Y-%m-%d"); y, w, _ = now.isocalendar(); wk = f"{y}-W{w}"
        if st.day_key != dk:
            st.day_key, st.day_start_equity = dk, equity
        if st.week_key != wk:
            st.week_key, st.week_start_equity = wk, equity

    def allowed(self, st, equity: float, api_errors: int = 0):
        if st.kill_switch: return False, "Kill Switch активний"
        if api_errors >= 3: return False, "API біржі нестабільне"
        if st.consecutive_losses >= st.max_consec_losses:
            return False, f"{st.consecutive_losses} збитків поспіль — потрібна ручна перевірка (/resume)"
        if st.day_start_equity > 0:
            dd = (st.day_start_equity - equity) / st.day_start_equity * 100
            if dd >= st.daily_dd_pct: return False, f"денна просадка {dd:.2f}% ≥ {st.daily_dd_pct}%"
        if st.week_start_equity > 0:
            dd = (st.week_start_equity - equity) / st.week_start_equity * 100
            if dd >= st.weekly_dd_pct: return False, f"тижнева просадка {dd:.2f}% ≥ {st.weekly_dd_pct}%"
        return True, ""

    def can_open(self, st, direction: str):
        if len(st.positions) >= st.max_positions: return False, "ліміт відкритих позицій"
        side = "long" if direction == "LONG" else "short"
        if sum(1 for p in st.positions if p.side == side) >= st.max_same_direction:
            return False, "надмірна експозиція в одному напрямку (корельовані активи)"
        return True, ""

    # ---------- розмір позиції ----------
    def size(self, equity, entry, sl, risk_pct, max_risk_pct, leverage, market, round_amount, fee=0.0005, slip=0.0002):
        risk_pct = min(risk_pct, max_risk_pct)
        cs = float(market.get("contractSize") or 1.0)
        dist = abs(entry - sl)
        if dist <= 0 or equity <= 0: return None, "некоректні вхідні дані"
        risk_amt = equity * risk_pct / 100
        unit_loss = dist + entry * 2 * fee + entry * 2 * slip      # збиток на 1 базову одиницю
        qty = round_amount(risk_amt / unit_loss / cs)
        max_notional = equity * leverage * 0.9
        if qty * cs * entry > max_notional:
            qty = round_amount(max_notional / entry / cs)
        mn = (market.get("limits", {}).get("amount", {}) or {}).get("min") or 0
        mc = (market.get("limits", {}).get("cost", {}) or {}).get("min") or 0
        if qty <= 0 or qty < mn: return None, f"qty {qty} < мін. {mn}"
        if qty * cs * entry < mc: return None, f"notional < мін. {mc}"
        if dist >= entry / leverage * 0.9 * 0.7:
            return None, "SL надто близько до ліквідації при цьому плечі"
        return {"qty": qty, "risk_usdt": qty * cs * unit_loss, "notional": qty * cs * entry,
                "margin": qty * cs * entry / leverage, "cs": cs}, ""
