"""Детекція Order Block та їх стану (fresh / tested / broken->breaker)."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import numpy as np
import pandas as pd


@dataclass
class OrderBlock:
    kind: str                 # 'bullish' | 'bearish'
    lo: float
    hi: float
    idx: int                  # свічка OB
    disp_idx: int             # свічка displacement, що його створила
    time: int                 # ts відкриття свічки OB (ms)
    status: str = "fresh"     # fresh | tested | broken
    broken_idx: Optional[int] = None   # перше ЗАКРИТТЯ за межею (не тінь)

    @property
    def mid(self) -> float:
        return (self.lo + self.hi) / 2


def detect_order_blocks(df: pd.DataFrame, atr_arr: np.ndarray, disp_mult=1.5, lookback_candles=5,
                        min_h_atr=0.3, max_h_atr=3.0) -> list[OrderBlock]:
    o = df["open"].to_numpy(); h = df["high"].to_numpy(); l = df["low"].to_numpy(); c = df["close"].to_numpy()
    ts = df["ts"].to_numpy(); n = len(df); out: list[OrderBlock] = []; used = set()
    for j in range(lookback_candles + 1, n):
        a = atr_arr[j]
        if np.isnan(a) or abs(c[j] - o[j]) < disp_mult * a:
            continue
        up = c[j] > o[j]
        if up and c[j] <= h[j - lookback_candles:j].max():
            continue
        if not up and c[j] >= l[j - lookback_candles:j].min():
            continue
        k = None
        for t in range(j - 1, j - lookback_candles - 1, -1):
            if (up and c[t] < o[t]) or (not up and c[t] > o[t]):
                k = t; break
        if k is None or (up, k) in used:
            continue
        height = h[k] - l[k]
        if not (min_h_atr * a <= height <= max_h_atr * a):
            continue
        used.add((up, k))
        ob = OrderBlock("bullish" if up else "bearish", float(l[k]), float(h[k]), k, j, int(ts[k]))
        for t in range(j + 1, n):
            if ob.kind == "bullish":
                if c[t] < ob.lo:
                    ob.status = "broken"; ob.broken_idx = t; break
                if l[t] <= ob.hi:
                    ob.status = "tested"
            else:
                if c[t] > ob.hi:
                    ob.status = "broken"; ob.broken_idx = t; break
                if h[t] >= ob.lo:
                    ob.status = "tested"
        out.append(ob)
    return out
